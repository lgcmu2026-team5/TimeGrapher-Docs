#include <QCoreApplication>
#include <QImage>
#include <QDebug>
#include <vector>
#include <cmath>

#include "SoundImageRendererV2_fully_documented.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    QImage image(80, 600, QImage::Format_ARGB32);

    SoundImageRenderer renderer;
    SoundImageRenderer::Config cfg;
    cfg.sample_rate_hz = 48000.0;
    cfg.bph = 28800.0;
    cfg.sound_color = qRgba(255, 0, 0, 255);
    cfg.background_color = qRgba(255, 255, 255, 255);
    cfg.vertical_time_direction = SoundImageRenderer::TimeStartsAtBottomMovesUp;
    cfg.warmup_columns = 0;
    cfg.anchor_columns = 1;
    cfg.gamma = 0.5f;
    cfg.live_preview_current_column = true;

    if (!renderer.initialize(&image, cfg)) {
        qCritical() << "Failed to initialize renderer.";
        return 1;
    }

    renderer.reset(0);

    const int samples_per_column =
        static_cast<int>(std::llround(renderer.samplesPerColumnExact()));
    const int total_columns = 120;

    std::vector<float> samples(static_cast<std::size_t>(samples_per_column * total_columns), 0.0f);
    std::vector<quint64> marker_indices;

    for (int col = 0; col < total_columns; ++col) {
        const int base = col * samples_per_column;
        const int peak = base + 1800;
        marker_indices.push_back(static_cast<quint64>(peak));

        for (int k = -2; k <= 2; ++k) {
            const int idx = peak + k;
            if (idx < base || idx >= base + samples_per_column) {
                continue;
            }

            if (k == 0) {
                samples[static_cast<std::size_t>(idx)] = 1.0f;
            } else if (std::abs(k) == 1) {
                samples[static_cast<std::size_t>(idx)] = 0.40f;
            } else {
                samples[static_cast<std::size_t>(idx)] = 0.15f;
            }
        }
    }

    renderer.processSamples(samples.data(), samples.size());

    for (int i = 0; i < static_cast<int>(marker_indices.size()); i += 10) {
        renderer.markCEventAbsoluteSampleIndex(
            marker_indices[static_cast<std::size_t>(i)],
            qRgba(0, 255, 0, 255),
            9);
    }

    image.save("SoundImageRendererV2_marker_bleed_patch_output.png");
    qDebug() << "Saved SoundImageRendererV2_marker_bleed_patch_output.png";

    return 0;
}
