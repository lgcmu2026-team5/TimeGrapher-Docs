#include "watch_synth_stream.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

static int run_case(FILE *f, double bph, unsigned sr, double be_ms, double amp_deg) {
    WatchSynthStreamConfig cfg;
    WatchSynthStream s;
    char err[256];
    float block[4096];
    WatchSynthStreamEvent ev[32];
    WatchSynthEventKind prev_kind = WATCH_SYNTH_EVENT_TICK;
    int have_prev = 0, event_count = 0, tt_n = 0, tk_n = 0;
    double tt_sum = 0.0, tk_sum = 0.0, atoc_sum = 0.0;
    size_t done = 0;
    size_t total_samples;
    double duration_s;
    watch_synth_stream_clean_config(&cfg);
    cfg.sample_rate_hz = sr;
    cfg.bph = bph;
    cfg.beat_error_ms = be_ms;
    cfg.watch_amplitude_degrees = amp_deg;
    cfg.lift_angle_degrees = 52.0;
    cfg.noise_peak_amplitude = 0.0;
    if (!watch_synth_stream_init(&s, &cfg, err, sizeof(err))) {
        fprintf(stderr, "init failed: %s\n", err);
        return 0;
    }
    duration_s = cfg.start_time_s + 4.0 * (3600.0 / cfg.bph);
    total_samples = (size_t)ceil(duration_s * (double)cfg.sample_rate_hz);
    while (done < total_samples && event_count < 4) {
        size_t n = sizeof(block)/sizeof(block[0]);
        size_t i;
        WatchSynthStreamFillResult r;
        if (n > total_samples - done) n = total_samples - done;
        r = watch_synth_stream_fill_f32(&s, block, n, ev, 32);
        for (i = 0; i < r.events_written; ++i) {
            double interval_ms = ev[i].interval_from_previous_us / 1000.0;
            if (have_prev && interval_ms > 0.0) {
                if (prev_kind == WATCH_SYNTH_EVENT_TICK) { tt_sum += interval_ms; tt_n++; }
                else { tk_sum += interval_ms; tk_n++; }
            }
            prev_kind = ev[i].kind;
            have_prev = 1;
            atoc_sum += ev[i].a_to_c_time_s * 1000.0;
            event_count++;
        }
        done += n;
    }
    if (tt_n > 0 && tk_n > 0) {
        double tt = tt_sum / tt_n;
        double tk = tk_sum / tk_n;
        double raw = tt - tk;
        double computed = 0.5 * raw;
        fprintf(f, "%.0f,%u,%.9f,%.3f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%d\n",
            bph, sr, be_ms, amp_deg, tt, tk, raw, computed,
            (computed - be_ms) * 1000.0, atoc_sum / event_count, event_count);
    }
    watch_synth_stream_destroy(&s);
    return 1;
}

int main(void) {
    const double bphs[] = {3600,7200,21600,28800};
    const unsigned srs[] = {44100,192000};
    const double bes[] = {5.0,8.0};
    FILE *f = fopen("runtime_subset_verification.csv", "wb");
    size_t bi, si, ei;
    if (!f) return 1;
    fprintf(f, "bph,sample_rate_hz,configured_beat_error_ms,watch_amplitude_degrees,mean_tick_to_tock_ms,mean_tock_to_tick_ms,raw_interval_difference_ms,computed_timegrapher_beat_error_ms,beat_error_error_us,mean_a_to_c_ms,event_count\n");
    for (bi = 0; bi < sizeof(bphs)/sizeof(bphs[0]); ++bi)
    for (si = 0; si < sizeof(srs)/sizeof(srs[0]); ++si)
    for (ei = 0; ei < sizeof(bes)/sizeof(bes[0]); ++ei)
        run_case(f, bphs[bi], srs[si], bes[ei], 300.0);
    fclose(f);
    return 0;
}
