#include "watch_synth_stream.h"
#include <math.h>
#include <stdio.h>

int main(void) {
    const double bphs[] = {3600,7200,12000,18000,21600,28800,36000,43200};
    const unsigned srs[] = {44100,48000,96000,192000,384000};
    const double bes[] = {0.210,5.0,8.0};
    const double amps[] = {180,270,300};
    FILE *f = fopen("verification_grid.csv", "wb");
    size_t bi, si, ei, ai;
    if (!f) return 1;
    fprintf(f, "bph,sample_rate_hz,configured_beat_error_ms,watch_amplitude_degrees,nominal_interval_ms,tick_to_tock_ms,tock_to_tick_ms,raw_interval_difference_ms,computed_timegrapher_beat_error_ms,beat_error_error_us,computed_a_to_c_ms,sample_period_us\n");
    for (bi = 0; bi < sizeof(bphs)/sizeof(bphs[0]); ++bi) {
        for (si = 0; si < sizeof(srs)/sizeof(srs[0]); ++si) {
            for (ei = 0; ei < sizeof(bes)/sizeof(bes[0]); ++ei) {
                for (ai = 0; ai < sizeof(amps)/sizeof(amps[0]); ++ai) {
                    WatchSynthStreamConfig cfg;
                    double nominal_ms, tick_ms, tock_ms, raw_diff_ms, computed_be_ms;
                    watch_synth_stream_clean_config(&cfg);
                    cfg.bph = bphs[bi];
                    cfg.sample_rate_hz = srs[si];
                    cfg.beat_error_ms = bes[ei];
                    cfg.watch_amplitude_degrees = amps[ai];
                    cfg.lift_angle_degrees = 52.0;
                    nominal_ms = (3600.0 / cfg.bph) * 1000.0;
                    tick_ms = nominal_ms + cfg.beat_error_ms;
                    tock_ms = nominal_ms - cfg.beat_error_ms;
                    raw_diff_ms = tick_ms - tock_ms;
                    computed_be_ms = 0.5 * raw_diff_ms;
                    fprintf(f, "%.0f,%u,%.9f,%.3f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f\n",
                        cfg.bph,
                        cfg.sample_rate_hz,
                        cfg.beat_error_ms,
                        cfg.watch_amplitude_degrees,
                        nominal_ms,
                        tick_ms,
                        tock_ms,
                        raw_diff_ms,
                        computed_be_ms,
                        (computed_be_ms - cfg.beat_error_ms) * 1000.0,
                        watch_synth_stream_compute_a_to_c_time_s(&cfg) * 1000.0,
                        1000000.0 / (double)cfg.sample_rate_hz);
                }
            }
        }
    }
    fclose(f);
    return 0;
}
