#include "watch_synth_stream.h"

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void write_le_u16(FILE *f, uint16_t v) {
    unsigned char b[2]; b[0] = (unsigned char)(v & 255u); b[1] = (unsigned char)((v >> 8) & 255u); fwrite(b,1,2,f);
}
static void write_le_u32(FILE *f, uint32_t v) {
    unsigned char b[4]; b[0] = (unsigned char)(v & 255u); b[1] = (unsigned char)((v >> 8) & 255u); b[2] = (unsigned char)((v >> 16) & 255u); b[3] = (unsigned char)((v >> 24) & 255u); fwrite(b,1,4,f);
}
static void write_wav16_header(FILE *f, uint32_t sample_rate_hz, uint32_t sample_count) {
    uint32_t data_bytes = sample_count * 2u;
    fwrite("RIFF",1,4,f); write_le_u32(f,36u + data_bytes); fwrite("WAVE",1,4,f);
    fwrite("fmt ",1,4,f); write_le_u32(f,16u); write_le_u16(f,1u); write_le_u16(f,1u);
    write_le_u32(f,sample_rate_hz); write_le_u32(f,sample_rate_hz * 2u); write_le_u16(f,2u); write_le_u16(f,16u);
    fwrite("data",1,4,f); write_le_u32(f,data_bytes);
}

int main(void) {
    WatchSynthStreamConfig cfg;
    WatchSynthStream stream;
    char err[256];
    const double duration_s = 5.0;
    const size_t block_n = 257;
    const uint32_t total_samples = (uint32_t)(duration_s * 48000.0 + 0.5);
    float block[257];
    WatchSynthStreamEvent events[32];
    uint32_t done = 0;
    FILE *wav = fopen("watch_synth_v1_demo.wav", "wb");
    FILE *f32 = fopen("watch_synth_v1_demo.f32", "wb");
    FILE *csv = fopen("watch_synth_v1_demo_events.csv", "wb");
    if (!wav || !f32 || !csv) return 1;

    watch_synth_stream_realistic_config(&cfg);
    cfg.sample_rate_hz = 48000;
    cfg.bph = 19800.0;
    cfg.beat_error_ms = 0.210;           /* timegrapher-style displayed beat error */
    cfg.watch_amplitude_degrees = 270.0;
    cfg.lift_angle_degrees = 52.0;
    cfg.pcm_peak_amplitude = 0.70;

    if (!watch_synth_stream_init(&stream, &cfg, err, sizeof(err))) {
        fprintf(stderr, "init failed: %s\n", err);
        return 1;
    }

    write_wav16_header(wav, cfg.sample_rate_hz, total_samples);
    fprintf(csv, "beat_index,kind,time_s,sample_index,interval_from_previous_us,applied_interval_offset_us,timing_jitter_us,bph_wander_us,packet_gain,a_to_c_time_s,watch_amplitude_degrees,lift_angle_degrees\n");

    while (done < total_samples) {
        size_t n = block_n;
        size_t i;
        WatchSynthStreamFillResult r;
        if (n > total_samples - done) n = total_samples - done;
        r = watch_synth_stream_fill_f32(&stream, block, n, events, 32);
        fwrite(block, sizeof(float), n, f32);
        for (i=0; i<n; ++i) {
            double v = block[i];
            int32_t s;
            if (v > 1.0) v = 1.0;
            if (v < -1.0) v = -1.0;
            s = (int32_t)lrint(v * 32767.0);
            if (s > 32767) s = 32767;
            if (s < -32768) s = -32768;
            write_le_u16(wav, (uint16_t)(int16_t)s);
        }
        for (i=0; i<r.events_written; ++i) {
            fprintf(csv, "%llu,%s,%.12f,%llu,%.6f,%.6f,%.6f,%.6f,%.9f,%.9f,%.3f,%.3f\n",
                (unsigned long long)events[i].beat_index,
                watch_synth_stream_event_kind_name(events[i].kind),
                events[i].time_s,
                (unsigned long long)events[i].sample_index,
                events[i].interval_from_previous_us,
                events[i].applied_interval_offset_us,
                events[i].timing_jitter_us,
                events[i].bph_wander_us,
                events[i].packet_gain,
                events[i].a_to_c_time_s,
                events[i].watch_amplitude_degrees,
                events[i].lift_angle_degrees);
        }
        done += (uint32_t)n;
    }

    fclose(wav); fclose(f32); fclose(csv);
    printf("Generated watch_synth_v1_demo.wav/f32/events.csv\n");
    printf("A_to_C_ms %.6f\n", 1000.0 * watch_synth_stream_compute_a_to_c_time_s(&cfg));
    return 0;
}
