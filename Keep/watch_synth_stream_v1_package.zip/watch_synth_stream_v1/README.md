# WatchSynthStreamV1

Stateful continuous mono float-PCM mechanical-watch signal synthesizer.

This version is the cleaned baseline after the timegrapher beat-error, corrected watch-amplitude/lift-angle, and high-sample-rate C-anchor fixes.

## Main API

```c
WatchSynthStreamConfig cfg;
WatchSynthStream stream;
float output[257];
WatchSynthStreamEvent events[16];
char err[256];

watch_synth_stream_realistic_config(&cfg);
cfg.sample_rate_hz = 48000;
cfg.bph = 19800.0;
cfg.beat_error_ms = 0.210;            /* timegrapher-style displayed beat error */
cfg.watch_amplitude_degrees = 270.0;  /* mechanical balance amplitude */
cfg.lift_angle_degrees = 52.0;        /* watch lift angle */
cfg.pcm_peak_amplitude = 0.70;        /* normalized float PCM output level */

if (!watch_synth_stream_init(&stream, &cfg, err, sizeof(err))) {
    /* handle error */
}

WatchSynthStreamFillResult r = watch_synth_stream_fill_f32(
    &stream,
    output,
    257,
    events,
    16);
```

## Units and conventions

### PCM amplitude

`pcm_peak_amplitude` is normalized digital output loudness. It is not mechanical watch amplitude.

```text
-1.0 = negative full scale
 0.0 = center/silence
+1.0 = positive full scale
```

### Timegrapher-style beat error

`beat_error_ms` is the beat error a timegrapher should display:

```text
beat_error_ms = 0.5 * (Tick->Tock interval - Tock->Tick interval)
```

So:

```text
cfg.beat_error_ms = 5.0 ms
Tick->Tock = nominal + 5.0 ms
Tock->Tick = nominal - 5.0 ms
raw interval difference = 10.0 ms
timegrapher displayed beat error = 5.0 ms
```

### Watch amplitude and lift angle

When `use_watch_amplitude_for_a_to_c` is enabled, A->C timing is computed from:

```text
A_to_C_s = (2 * beat_interval_s / pi) * asin(lift_angle_degrees / (2 * watch_amplitude_degrees))
```

This gives realistic millisecond-scale spacing. For example, at 19,800 BPH, 52° lift, 270° amplitude, A->C is about 11.16 ms.

## C peak anchor

The old `c_peak_advance_s` setting has been removed. The current C-lock path uses a narrow Gaussian anchor exactly at the computed A->C time:

```c
cfg.enable_c_peak_lock = 1;
cfg.c_peak_anchor_gain = 3.00;
cfg.c_peak_anchor_width_s = 0.000020; /* 20 us */
cfg.post_c_lobe_scale = 0.22;
```

This keeps high-BPH/high-sample-rate timegrapher amplitude readings tied to the configured `watch_amplitude_degrees` rather than letting later C ringing steal the peak.

## Defaults

- `watch_synth_stream_clean_config()` — low-variation timing/formula verification.
- `watch_synth_stream_realistic_config()` — realistic packet variation, drift, resonance, band-limited noise, BPH wander, Tick/Tock spectral differences, and C peak lock.
- `watch_synth_stream_default_config()` — currently aliases realistic.

## Build

```bash
gcc -O2 -std=c99 -Wall -Wextra -pedantic \
    watch_synth_stream.c example_stream_to_wav.c \
    -lm -o example_stream_to_wav
```

## Verification included

- `verification_grid.csv`: full formula grid over BPH, sample rate, beat error, and watch amplitude.
- `runtime_subset_verification.csv`: actual streaming runtime check at selected low/high BPH and sample rates.
- `watch_synth_v1_demo.wav`: generated demo WAV.
- `watch_synth_v1_demo.f32`: generated raw float PCM.
- `watch_synth_v1_demo_events.csv`: ground-truth event output.
