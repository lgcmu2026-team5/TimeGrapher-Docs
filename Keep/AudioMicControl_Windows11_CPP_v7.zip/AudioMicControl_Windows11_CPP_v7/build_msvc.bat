@echo off
setlocal

REM Build from a Visual Studio Developer Command Prompt.
REM Example:
REM   x64 Native Tools Command Prompt for VS 2022
REM   build_msvc.bat

cl /std:c++17 /EHsc AudioMicControl.cpp ole32.lib uuid.lib

endlocal
