# AudioMicControl - Windows 11 C++ Core Audio Utility v7

This version fixes a v6 source-generation mistake where a few diagnostic `std::wcerr` messages contained real newlines inside wide string literals.

v7 keeps the intended v6 matching behavior:

1. First pass: look for exact `Endpoint friendly name` matches.
2. If exactly one exact match exists, use it immediately.
3. If multiple exact matches exist, report ambiguity.
4. Only if no exact match exists, fall back to case-insensitive substring matching.

## Build with MSVC

```bat
build_msvc.bat
```

Or directly:

```bat
cl /std:c++17 /EHsc AudioMicControl.cpp ole32.lib uuid.lib
```

## Build with MinGW-w64

```bat
g++ -std=c++17 -municode AudioMicControl.cpp -lole32 -luuid -lpropsys -o AudioMicControl.exe
```

If you get `PKEY_Device_FriendlyName` linker errors, add `WindowsPropertyKeys.cpp` to exactly one target.

## Usage

```bat
AudioMicControl.exe --set-mic "Microphone Array (Realtek(R) Audio)" 75
AudioMicControl.exe --agc "Microphone Array (Realtek(R) Audio)"
AudioMicControl.exe --set-mic "array" "realtek" 75
AudioMicControl.exe --set-mic-id "{endpoint-id-from-list}" 75
```
