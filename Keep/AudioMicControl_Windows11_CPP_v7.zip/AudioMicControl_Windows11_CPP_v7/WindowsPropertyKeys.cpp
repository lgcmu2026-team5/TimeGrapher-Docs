// WindowsPropertyKeys.cpp
//
// Optional helper for MinGW/CMake builds that get linker errors such as:
//
//   undefined reference to `PKEY_Device_FriendlyName'
//
// Add this file to exactly one target if needed.
//
// Do NOT include this file from another .cpp.
// Do NOT put #define INITGUID in a header.
// Do NOT compile this file into the same target more than once.

#define INITGUID

#include <windows.h>
#include <initguid.h>
#include <propsys.h>
#include <functiondiscoverykeys_devpkey.h>
