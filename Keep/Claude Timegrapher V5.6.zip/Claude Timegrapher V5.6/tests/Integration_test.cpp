/* tests/Integration_test.cpp - V5.6 cross-library smoke test.
 *
 * Generates synthetic 21600 BPH tick streams with configurable beat
 * error, runs them end-to-end through libtimegrapher + libtgan +
 * libtgacf, and asserts that detection, pairing, and ACF readouts
 * produce sensible values matching what was synthesized.
 */
#include "Timegrapher.h"
#include "Tgan.h"
#include "Tgacf.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define ASSERT(cond, fmt, ...) do { \
    if (!(cond)) { \
        fprintf(stderr, "FAIL: " fmt "\n", ##__VA_ARGS__); \
        return 1; \
    } \
} while (0)

/* Generate synthetic 21600 BPH ticks. If beat_error_ms > 0, alternate
 * beats are shifted by +beat_error_ms (the canonical timegrapher
 * encoding: alternating long/short A-to-A intervals). */
static void generate_ticks(float *pcm, size_t n, double fs,
                           double beat_error_ms)
{
    memset(pcm, 0, n * sizeof(float));
    double period = 3600.0 / 21600.0;
    double ac_gap = 0.008;
    double tick_dur = 0.003;
    double f_carrier = 1500.0;
    double tau = 0.0008;

    int beat_idx = 0;
    for (double t_nom = 0.05; t_nom < (double)n / fs; t_nom += period) {
        double t = t_nom;
        if (beat_error_ms > 0.0 && (beat_idx & 1)) {
            t += beat_error_ms * 0.001;
        }
        size_t s0 = (size_t)(t * fs);
        size_t s1 = (size_t)((t + tick_dur) * fs);
        if (s1 > n) s1 = n;
        for (size_t s = s0; s < s1; s++) {
            double dt = (double)(s - s0) / fs;
            pcm[s] += (float)(0.5 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        size_t c0 = (size_t)((t + ac_gap) * fs);
        size_t c1 = (size_t)((t + ac_gap + tick_dur) * fs);
        if (c1 > n) c1 = n;
        for (size_t s = c0; s < c1; s++) {
            double dt = (double)(s - c0) / fs;
            pcm[s] += (float)(0.6 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        beat_idx++;
    }
}

/* Generate synthetic 21600 BPH ticks with a TALL spurious sub-impulse
 * 3.5 ms after every A. This reproduces the Wrong_C.wav failure mode
 * where an intermediate hump within the burst can latch as the burst
 * maximum and be mis-placed as C. The C-search-skip mechanism (V5.2)
 * should reject this hump and place C at the real C cluster (8 ms
 * after A). */
static void generate_ticks_with_mid_hump(float *pcm, size_t n, double fs)
{
    memset(pcm, 0, n * sizeof(float));
    double period = 3600.0 / 21600.0;
    double ac_gap = 0.008;
    double tick_dur = 0.003;
    double f_carrier = 1500.0;
    double tau = 0.0008;
    double mid_hump_offset = 0.0035;   /* 3.5 ms after A */

    for (double t = 0.05; t < (double)n / fs; t += period) {
        /* A pulse */
        size_t s0 = (size_t)(t * fs);
        size_t s1 = (size_t)((t + tick_dur) * fs);
        if (s1 > n) s1 = n;
        for (size_t s = s0; s < s1; s++) {
            double dt = (double)(s - s0) / fs;
            pcm[s] += (float)(0.5 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        /* Mid-burst spurious hump - made TALLER than A and C to
         * verify the skip rejects it even when it's the burst max */
        size_t m0 = (size_t)((t + mid_hump_offset) * fs);
        size_t m1 = (size_t)((t + mid_hump_offset + tick_dur) * fs);
        if (m1 > n) m1 = n;
        for (size_t s = m0; s < m1; s++) {
            double dt = (double)(s - m0) / fs;
            pcm[s] += (float)(0.7 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        /* C pulse */
        size_t c0 = (size_t)((t + ac_gap) * fs);
        size_t c1 = (size_t)((t + ac_gap + tick_dur) * fs);
        if (c1 > n) c1 = n;
        for (size_t s = c0; s < c1; s++) {
            double dt = (double)(s - c0) / fs;
            pcm[s] += (float)(0.6 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
    }
}

/* Generate 18000 BPH ticks with an aftershock impulse 50 ms after each
 * main beat (mimicking the Watham V2 / Out1 / Out2 recordings).
 * Pre-sync the aftershock fires its own A event, doubling the apparent
 * event rate. This previously caused 36000 BPH to be mis-detected
 * because the Rayleigh phase-score returned R1+R2 (the second harmonic
 * doubled the score for half-period candidates). V5.3 returns R1 only
 * and adds a median-A-to-A guard to break the period/half-period
 * aliasing. */
static void generate_18000_with_aftershock(float *pcm, size_t n, double fs)
{
    memset(pcm, 0, n * sizeof(float));
    double period = 3600.0 / 18000.0;   /* 200 ms */
    double ac_gap = 0.0093;              /* 9.3 ms typical */
    double aftershock_offset = 0.050;    /* 50 ms after A */
    double tick_dur = 0.003;
    double f_carrier = 1500.0;
    double tau = 0.0008;

    for (double t = 0.05; t < (double)n / fs; t += period) {
        /* Main A pulse */
        size_t s0 = (size_t)(t * fs);
        size_t s1 = (size_t)((t + tick_dur) * fs);
        if (s1 > n) s1 = n;
        for (size_t s = s0; s < s1; s++) {
            double dt = (double)(s - s0) / fs;
            pcm[s] += (float)(0.5 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        /* C pulse */
        size_t c0 = (size_t)((t + ac_gap) * fs);
        size_t c1 = (size_t)((t + ac_gap + tick_dur) * fs);
        if (c1 > n) c1 = n;
        for (size_t s = c0; s < c1; s++) {
            double dt = (double)(s - c0) / fs;
            pcm[s] += (float)(0.6 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
        /* Aftershock at +50 ms (smaller, but enough to clear the
         * onset threshold pre-sync). */
        size_t a0 = (size_t)((t + aftershock_offset) * fs);
        size_t a1 = (size_t)((t + aftershock_offset + tick_dur) * fs);
        if (a1 > n) a1 = n;
        for (size_t s = a0; s < a1; s++) {
            double dt = (double)(s - a0) / fs;
            pcm[s] += (float)(0.3 * exp(-dt / tau) *
                              sin(2 * M_PI * f_carrier * dt));
        }
    }
}

/* Run a synthetic stream end-to-end and assert results. Returns 0
 * on success. If `mid_hump` is non-zero, generates a Wrong_C-style
 * stream with a tall spurious sub-impulse 3.5 ms into each burst;
 * the test then asserts that no A->C gap is shorter than 7 ms (the
 * C-search-skip mechanism should reject the hump and place C at the
 * real C cluster ~8 ms past A). */
/* Run a synthetic stream end-to-end and assert results. Returns 0
 * on success.
 *
 * gen_kind selects the generator:
 *   0 = clean 21600 BPH (with optional beat_error_ms)
 *   1 = 21600 BPH with mid-burst hump (Wrong_C-style; tests C-skip)
 *   2 = 18000 BPH with +50 ms aftershock (tests V5.3 half-period guard)
 *
 * expected_bph is the BPH that detection should report. */
static int run_case(const char *label, double duration, double fs,
                    double lift, double beat_error_ms, int gen_kind,
                    int expected_bph, tg_c_placement_t placement)
{
    printf("\n== %s ==\n", label);
    size_t n = (size_t)(fs * duration);
    float *pcm = (float*)malloc(n * sizeof(float));
    if (!pcm) return 1;
    switch (gen_kind) {
    case 1: generate_ticks_with_mid_hump(pcm, n, fs); break;
    case 2: generate_18000_with_aftershock(pcm, n, fs); break;
    default: generate_ticks(pcm, n, fs, beat_error_ms); break;
    }

    tg_config_t tg_cfg; tg_config_default(&tg_cfg);
    tg_cfg.sample_rate = fs;
    tg_cfg.bph_mode    = TG_BPH_MODE_AUTO;
    tg_cfg.c_placement = placement;
    tg_context_t *tg = tg_init(&tg_cfg);
    ASSERT(tg, "tg_init failed");

    tga_config_t an_cfg; tga_config_default(&an_cfg);
    an_cfg.lift_angle_deg = lift;
    an_cfg.gate           = TGA_GATE_MEDIUM;
    tga_analyzer_t *an = tga_create(&an_cfg);
    ASSERT(an, "tga_create failed");

    tgacf_config_t acf_cfg; tgacf_config_default(&acf_cfg);
    acf_cfg.sample_rate = fs;
    acf_cfg.c_placement = placement;
    tgacf_estimator_t *acf = tgacf_create(&acf_cfg);
    ASSERT(acf, "tgacf_create failed");

    int total_a = 0, total_c = 0, total_pairs = 0;
    double amp_sum = 0;
    int detected_bph = 0;
    double last_period = 0;
    tga_event_t analyzed[256];
    tgacf_result_t last_acf = {};
    int got_acf = 0;
    uint64_t samples_since_last_acf = 0;

    /* Track A->C gaps for the multi-impulse test. */
    double last_a_time = -1.0;
    int    tight_gap_count = 0;     /* gaps < 7 ms (post-sync only) */
    double min_ac_gap_ms = 1e9;

    size_t pos = 0;
    while (pos < n) {
        size_t k = (pos + 4096 <= n) ? 4096 : (n - pos);
        tg_result_t r;
        ASSERT(tg_process(tg, pcm + pos, k, &r) == 0, "tg_process failed");

        if (r.processed_pcm_len > 0) {
            tgacf_push_envelope(acf, r.processed_pcm,
                                r.processed_pcm_len,
                                r.processed_pcm_start_sample);
        }

        if (r.sync_acquired_event) {
            detected_bph = r.detected_bph;
            tga_update_period(an, r.measured_period_s);
            for (size_t i = 0; i < r.num_events; i++) {
                if (r.events[i].type == TG_EVENT_A &&
                    !r.events[i].is_pre_sync) {
                    tga_notify_sync_acquired(an, r.events[i].time_seconds);
                    break;
                }
            }
        }
        if (r.sync_lost_event) tga_notify_sync_lost(an);
        if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0) {
            tga_update_period(an, r.measured_period_s);
            last_period = r.measured_period_s;
        }

        size_t na = tga_analyze(an, r.events, r.num_events,
                                analyzed, 256);
        for (size_t i = 0; i < na; i++) {
            tga_event_t *e = &analyzed[i];
            if (e->type == TG_EVENT_A) {
                total_a++;
                tgacf_push_a_event(acf, e->time_seconds);
                if (!e->is_pre_sync) last_a_time = e->time_seconds;
                else                 last_a_time = -1.0;
            } else {
                total_c++;
                if (e->amplitude_valid) {
                    total_pairs++;
                    amp_sum += e->amplitude_deg;
                }
                if (last_a_time > 0) {
                    double dt = (e->time_seconds - last_a_time) * 1000.0;
                    if (dt < min_ac_gap_ms) min_ac_gap_ms = dt;
                    if (dt < 7.0) tight_gap_count++;
                }
                last_a_time = -1.0;
            }
        }

        samples_since_last_acf += k;
        if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0
            && samples_since_last_acf >= (uint64_t)fs)
        {
            tgacf_result_t ar;
            if (tgacf_estimate(acf, r.measured_period_s, lift, &ar)) {
                last_acf = ar;
                got_acf  = 1;
            }
            samples_since_last_acf = 0;
        }
        pos += k;
    }

    printf("  detected_bph=%d period=%.6fs\n", detected_bph, last_period);
    printf("  A=%d C=%d pairs=%d  mean_amp=%.1f deg\n",
           total_a, total_c, total_pairs,
           total_pairs ? amp_sum/total_pairs : 0);
    printf("  min A->C gap=%.2fms tight (<7ms): %d\n",
           min_ac_gap_ms < 1e8 ? min_ac_gap_ms : 0.0, tight_gap_count);
    if (got_acf) {
        printf("  ACF: period=%.6fs amp=%.1f beat_err=%.2fms beats=%d\n",
               last_acf.period_s, last_acf.amplitude_deg,
               last_acf.beat_error_ms, last_acf.beats_used);
    }

    /* Detection */
    ASSERT(detected_bph == expected_bph, "bph %d != %d",
           detected_bph, expected_bph);
    ASSERT(total_a == total_c, "A=%d != C=%d", total_a, total_c);
    /* Amplitude check (looser bounds for the aftershock case which
     * synthesizes a smaller A->C gap, hence higher amplitude). */
    if (total_pairs > 0) {
        double mean = amp_sum / total_pairs;
        ASSERT(mean > 200 && mean < 360,
               "mean amp %.1f outside [200, 360]", mean);
    }
    /* ACF beat error must match the synthesized value to ~0.5 ms */
    if (got_acf && beat_error_ms > 0.5) {
        ASSERT(fabs(last_acf.beat_error_ms - beat_error_ms) < 0.5,
               "ACF beat_err %.2f != synth %.2f", last_acf.beat_error_ms,
               beat_error_ms);
    }
    if (got_acf && beat_error_ms <= 0.5 && gen_kind == 0) {
        ASSERT(last_acf.beat_error_ms < 1.0,
               "ACF beat_err %.2f for zero-BE synth (>1.0)",
               last_acf.beat_error_ms);
    }
    /* V5.2 wrong-C check: with the mid-burst hump, no A->C gap
     * should fall below 7 ms (real C cluster is at 8 ms). The
     * C-search-skip mechanism should reject the spurious hump.
     *
     * Allow up to 2 tight gaps to account for events emitted in
     * the same batch as sync acquisition (where the skip is still
     * the pre-sync 3 ms default that doesn't cover the 3.5 ms hump
     * on this synthetic stream). */
    if (gen_kind == 1) {
        ASSERT(tight_gap_count <= 2,
               "%d tight A->C gaps found (min %.2fms); C-search-skip "
               "failed to reject mid-burst hump on most beats",
               tight_gap_count, min_ac_gap_ms);
    }

    tgacf_destroy(acf);
    tga_destroy(an);
    tg_destroy(tg);
    free(pcm);
    return 0;
}

int main(void) {
    printf("== V5.6 integration test ==\n");
    int rc;
    /* All existing cases run in default PEAK mode -- backward compat. */
    rc = run_case("zero beat error",   8.0, 48000.0, 50.0, 0.0, 0,
                  21600, TG_C_PLACEMENT_PEAK);
    if (rc) return rc;
    rc = run_case("6 ms beat error",   8.0, 48000.0, 50.0, 6.0, 0,
                  21600, TG_C_PLACEMENT_PEAK);
    if (rc) return rc;
    rc = run_case("9.9 ms beat error", 10.0, 48000.0, 50.0, 9.9, 0,
                  21600, TG_C_PLACEMENT_PEAK);
    if (rc) return rc;
    rc = run_case("multi-impulse (mid-burst hump)",
                  8.0, 48000.0, 50.0, 0.0, 1, 21600, TG_C_PLACEMENT_PEAK);
    if (rc) return rc;
    rc = run_case("18000 BPH with +50ms aftershock (V5.3 half-period guard)",
                  8.0, 48000.0, 50.0, 0.0, 2, 18000, TG_C_PLACEMENT_PEAK);
    if (rc) return rc;
    /* V5.4: same generators in ONSET mode. The clean synthetic test
     * uses zero-rise-time impulses, so onset and peak coincide -- the
     * result should be virtually identical to PEAK mode. */
    rc = run_case("V5.4 ONSET mode: zero beat error",
                  8.0, 48000.0, 50.0, 0.0, 0, 21600, TG_C_PLACEMENT_ONSET);
    if (rc) return rc;
    rc = run_case("V5.4 ONSET mode: multi-impulse (mid-burst hump)",
                  8.0, 48000.0, 50.0, 0.0, 1, 21600, TG_C_PLACEMENT_ONSET);
    if (rc) return rc;
    printf("\nAll assertions passed.\n");
    return 0;
}
