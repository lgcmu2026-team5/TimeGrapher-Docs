/* Test_basic.cpp -- detection-only smoke test for libtimegrapher.
 *
 * Reads a float32 PCM file, runs it through tg_init / tg_process /
 * tg_destroy with default config, and writes two outputs:
 *
 *   <out_prefix>.evt   -- CSV of detected events:
 *                         time_seconds,type,peak_value,is_pre_sync
 *                         where type is "A" or "C".
 *
 *   <out_prefix>.env   -- raw float32 envelope samples (for plotting
 *                         or comparison against an expected envelope).
 *
 * Used as a quick regression / diff target: re-run after detector
 * changes and compare .evt files byte-for-byte to confirm no
 * unintended timing drift.
 *
 * V5.5: file renamed from test_basic.c to Test_basic.cpp; compiles
 * under C++17. */
#include "Timegrapher.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc < 4) {
        fprintf(stderr, "usage: %s in.f32 sample_rate out_prefix\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) return 2;
    fseek(f, 0, SEEK_END); long bytes = ftell(f); fseek(f, 0, SEEK_SET);
    size_t n = bytes / 4;
    float *pcm = malloc(n*4);
    if (fread(pcm, 4, n, f) != n) { fclose(f); free(pcm); return 3; }
    fclose(f);

    tg_config_t cfg; tg_config_default(&cfg);
    cfg.sample_rate = atof(argv[2]);
    cfg.bph_mode = TG_BPH_MODE_AUTO;

    char path[1024];
    snprintf(path, sizeof(path), "%s.evt", argv[3]);
    FILE *fe = fopen(path, "w");
    fprintf(fe, "time,type,peak\n");

    tg_context_t *ctx = tg_init(&cfg);
    int A=0, C=0;
    size_t pos = 0;
    while (pos < n) {
        size_t k = (pos+4096<=n)? 4096 : (n-pos);
        tg_result_t r;
        tg_process(ctx, pcm+pos, k, &r);
        for (size_t i = 0; i < r.num_events; i++) {
            tg_event_t *e = &r.events[i];
            fprintf(fe, "%.6f,%c,%.6f\n", e->time_seconds,
                    e->type==TG_EVENT_A?'A':'C', e->peak_value);
            if (e->type==TG_EVENT_A) A++; else C++;
        }
        pos += k;
    }
    tg_result_t rf;
    tg_flush(ctx, &rf);
    for (size_t i = 0; i < rf.num_events; i++) {
        tg_event_t *e = &rf.events[i];
        fprintf(fe, "%.6f,%c,%.6f\n", e->time_seconds,
                e->type==TG_EVENT_A?'A':'C', e->peak_value);
        if (e->type==TG_EVENT_A) A++; else C++;
    }
    fclose(fe);
    printf("A=%d C=%d\n", A, C);
    tg_destroy(ctx); free(pcm);
    return 0;
}
