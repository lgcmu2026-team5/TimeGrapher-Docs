/* Test_tg_tgacf.cpp -- libtimegrapher + libtgacf integration tool.
 *
 * Drives the detector + autocorrelation analyzer end-to-end on a
 * float32 PCM input. Prints detected BPH, beat period from the ACF
 * window, amplitude (median A->C gap formula), and beat error.
 *
 * Used during V5.x development to verify that envelope hand-off and
 * A-event timestamps flow through libtgacf correctly without the
 * libtgan amplitude path in between.
 *
 * Usage: Test_tg_tgacf in.f32 sample_rate
 *
 * V5.5: file renamed from test_tg_tgacf.c; compiles under C++17.
 */
#include "Timegrapher.h"
#include "Tgacf.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc < 3) return 1;
    FILE *f = fopen(argv[1], "rb");
    fseek(f, 0, SEEK_END); long bytes = ftell(f); fseek(f, 0, SEEK_SET);
    size_t n = bytes / 4;
    float *pcm = malloc(n*4);
    if (fread(pcm, 4, n, f) != n) return 2;
    fclose(f);

    tg_config_t tg_cfg; tg_config_default(&tg_cfg);
    tg_cfg.sample_rate = atof(argv[2]);
    tg_context_t *tg = tg_init(&tg_cfg);

    tgacf_config_t acf_cfg; tgacf_config_default(&acf_cfg);
    acf_cfg.sample_rate = atof(argv[2]);
    tgacf_estimator_t *acf = tgacf_create(&acf_cfg);

    int A=0, C=0;
    int blocks = 0;
    size_t pos = 0;
    while (pos < n) {
        size_t k = (pos + 4096 <= n) ? 4096 : (n - pos);
        tg_result_t r;
        tg_process(tg, pcm + pos, k, &r);
        printf("block %d t=%.3fs num_events=%zu env_len=%zu\n",
               blocks, (double)pos/atof(argv[2]),
               r.num_events, r.processed_pcm_len);
        fflush(stdout);
        if (r.processed_pcm_len > 0) {
            tgacf_push_envelope(acf, r.processed_pcm, r.processed_pcm_len,
                                r.processed_pcm_start_sample);
        }
        for (size_t i = 0; i < r.num_events; i++) {
            if (r.events[i].type == TG_EVENT_A) {
                A++;
                tgacf_push_a_event(acf, r.events[i].time_seconds);
            }
            if (r.events[i].type == TG_EVENT_C) C++;
        }
        pos += k;
        blocks++;
        /* removed limit */  /* limit to first few blocks for trace */
    }
    printf("Done: A=%d C=%d\n", A, C);
    tgacf_destroy(acf); tg_destroy(tg); free(pcm);
    return 0;
}
