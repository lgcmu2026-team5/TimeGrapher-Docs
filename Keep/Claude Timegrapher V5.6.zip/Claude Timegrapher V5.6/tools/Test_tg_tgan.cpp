/* Test_tg_tgan.cpp -- libtimegrapher + libtgan integration tool.
 *
 * Drives the detector + per-event analyzer end-to-end on a float32
 * PCM input. Prints detected BPH and per-event amplitudes for paired
 * A->C events.
 *
 * Used during V5.x development to verify the event-stream hand-off
 * and per-pair amplitude computation without the libtgacf
 * autocorrelation path running in parallel.
 *
 * Usage: Test_tg_tgan in.f32 sample_rate
 *
 * V5.5: file renamed from test_tg_tgan.c; compiles under C++17.
 */
#include "Timegrapher.h"
#include "Tgan.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc < 3) return 1;
    FILE *f = fopen(argv[1], "rb");
    fseek(f, 0, SEEK_END); long bytes = ftell(f); fseek(f, 0, SEEK_SET);
    size_t n = bytes / 4;
    float *pcm = malloc(n*4);
    if (fread(pcm, 4, n, f) != n) return 2;
    fclose(f);

    tg_config_t tg_cfg; tg_config_default(&tg_cfg);
    tg_cfg.sample_rate = atof(argv[2]);
    tg_context_t *tg = tg_init(&tg_cfg);

    tga_config_t an_cfg; tga_config_default(&an_cfg);
    an_cfg.lift_angle_deg = 50;
    tga_analyzer_t *an = tga_create(&an_cfg);

    tga_event_t aev[256];
    int A=0, C=0, pairs=0;
    double amp_sum = 0;
    size_t pos = 0;
    while (pos < n) {
        size_t k = (pos + 4096 <= n) ? 4096 : (n - pos);
        tg_result_t r;
        tg_process(tg, pcm + pos, k, &r);
        if (r.sync_acquired_event) {
            tga_update_period(an, r.measured_period_s);
            for (size_t i = 0; i < r.num_events; i++) {
                if (r.events[i].type == TG_EVENT_A &&
                    !r.events[i].is_pre_sync) {
                    tga_notify_sync_acquired(an, r.events[i].time_seconds);
                    break;
                }
            }
        }
        if (r.sync_lost_event) tga_notify_sync_lost(an);
        if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0)
            tga_update_period(an, r.measured_period_s);
        size_t na = tga_analyze(an, r.events, r.num_events, aev, 256);
        for (size_t i = 0; i < na; i++) {
            if (aev[i].type == TG_EVENT_A) A++;
            if (aev[i].type == TG_EVENT_C) {
                C++;
                if (aev[i].amplitude_valid) { pairs++; amp_sum += aev[i].amplitude_deg; }
            }
        }
        pos += k;
    }
    printf("A=%d C=%d pairs=%d mean_amp=%.1f\n",
           A, C, pairs, pairs ? amp_sum/pairs : 0);
    tga_destroy(an); tg_destroy(tg); free(pcm);
    return 0;
}
