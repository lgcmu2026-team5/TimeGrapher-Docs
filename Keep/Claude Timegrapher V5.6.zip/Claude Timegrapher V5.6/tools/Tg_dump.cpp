/* Tg_dump.cpp -- Reference integration tool for the full pipeline.
 *
 * Drives all three libraries (libtimegrapher + libtgan + libtgacf)
 * end-to-end on a float32 PCM input. Reproduces the historical V4.5
 * tg_dump output: prints a one-line summary (detected BPH, A and C
 * counts, per-event amplitude, ACF period/amplitude/beat-error) and
 * writes two artifact files for downstream inspection:
 *
 *   <out_prefix>.evt   -- CSV of all events emitted by the detector
 *                         (time, type, peak value, pre-sync flag).
 *
 *   <out_prefix>.env   -- raw float32 envelope samples produced by
 *                         the DSP front-end (after HPF and rectify+LPF).
 *
 * Pre-sync events are included in .evt by default so visualizations
 * can show what the detector saw before BPH lock.
 *
 * Usage: Tg_dump in.f32 sample_rate lift_angle_deg out_prefix
 *
 * V5.5: file renamed from tg_dump.c to Tg_dump.cpp; compiles under
 * C++17. Same command-line interface and output formats as V5.4.
 */
#include "Timegrapher.h"
#include "Tgan.h"
#include "Tgacf.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc < 5) {
        fprintf(stderr,
            "usage: %s in.f32 sample_rate lift_angle_deg out_prefix\n",
            argv[0]);
        return 1;
    }
    double fs   = atof(argv[2]);
    double lift = atof(argv[3]);

    /* Load the entire .f32 file. */
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 2; }
    fseek(f, 0, SEEK_END); long bytes = ftell(f); fseek(f, 0, SEEK_SET);
    size_t n = bytes / 4;
    float *pcm = (float*)malloc(n * sizeof(float));
    if (!pcm) return 3;
    if (fread(pcm, 4, n, f) != n) { free(pcm); fclose(f); return 4; }
    fclose(f);

    /* libtimegrapher: detection */
    tg_config_t tg_cfg;
    tg_config_default(&tg_cfg);
    tg_cfg.sample_rate = fs;
    tg_cfg.bph_mode    = TG_BPH_MODE_AUTO;
    tg_context_t *tg = tg_init(&tg_cfg);
    if (!tg) { fprintf(stderr, "tg_init failed\n"); free(pcm); return 5; }

    /* libtgan: amplitude + gate (will be reconfigured once BPH locks) */
    tga_config_t an_cfg;
    tga_config_default(&an_cfg);
    an_cfg.lift_angle_deg = lift;
    tga_analyzer_t *an = tga_create(&an_cfg);

    /* libtgacf: rolling readouts */
    tgacf_config_t acf_cfg;
    tgacf_config_default(&acf_cfg);
    acf_cfg.sample_rate = fs;
    tgacf_estimator_t *acf = tgacf_create(&acf_cfg);

    /* Output files */
    char path[2048];
    snprintf(path, sizeof(path), "%s.evt", argv[4]);
    FILE *fe = fopen(path, "w");
    fprintf(fe, "time,type,peak,amplitude\n");
    snprintf(path, sizeof(path), "%s.env", argv[4]);
    FILE *fenv = fopen(path, "wb");

    /* Summary state */
    int    A_count = 0, C_count = 0, pair_count = 0;
    double amp_sum = 0;
    int    detected_bph = 0;
    double last_acf_period_s = 0, last_acf_amp = 0, last_acf_be = 0;
    int    last_acf_beats = 0;
    /* Rate-limit ACF estimate calls to once per second of audio.
     * Each estimate is O(win_samples * search_range) ≈ tens of
     * milliseconds; calling per-block would be far too slow. */
    uint64_t samples_since_last_acf = 0;
    uint64_t acf_estimate_interval = (uint64_t)fs;  /* 1 second */

    tga_event_t analyzed_events[256];

    size_t pos = 0;
    while (pos < n) {
        size_t k = (pos + 4096 <= n) ? 4096 : (n - pos);
        tg_result_t r;
        tg_process(tg, pcm + pos, k, &r);

        /* Push delayed envelope into ACF estimator */
        if (r.processed_pcm_len > 0) {
            tgacf_push_envelope(acf, r.processed_pcm, r.processed_pcm_len,
                                r.processed_pcm_start_sample);
            fwrite(r.processed_pcm, sizeof(float), r.processed_pcm_len, fenv);
        }

        /* Tell the analyzer when sync acquires (use last_event_time). */
        if (r.sync_acquired_event && r.num_events > 0) {
            tga_update_period(an, r.measured_period_s);
            /* phase reference = the last A event in this block */
            double sync_t = 0;
            for (size_t i = 0; i < r.num_events; i++) {
                if (r.events[i].type == TG_EVENT_A &&
                    !r.events[i].is_pre_sync)
                    sync_t = r.events[i].time_seconds;
            }
            if (sync_t > 0) tga_notify_sync_acquired(an, sync_t);
            detected_bph = r.detected_bph;
        }
        if (r.sync_lost_event) {
            tga_notify_sync_lost(an);
        }
        /* Keep period fresh */
        if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0) {
            tga_update_period(an, r.measured_period_s);
        }

        /* Run analytics over the events */
        size_t n_an = tga_analyze(an, r.events, r.num_events,
                                  analyzed_events, 256);
        for (size_t i = 0; i < n_an; i++) {
            tga_event_t *e = &analyzed_events[i];
            fprintf(fe, "%.6f,%c,%.6f,%.2f\n",
                    e->time_seconds,
                    e->type == TG_EVENT_A ? 'A' : 'C',
                    e->peak_value,
                    e->amplitude_deg);
            if (e->type == TG_EVENT_A) {
                A_count++;
                tgacf_push_a_event(acf, e->time_seconds);
            }
            if (e->type == TG_EVENT_C) {
                C_count++;
                if (e->amplitude_valid) {
                    pair_count++;
                    amp_sum += e->amplitude_deg;
                }
            }
        }

        /* ACF readout (rate-limited: once per second) */
        samples_since_last_acf += k;
        if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0
            && samples_since_last_acf >= acf_estimate_interval)
        {
            tgacf_result_t ar;
            if (tgacf_estimate(acf, r.measured_period_s, lift, &ar)) {
                last_acf_period_s = ar.period_s;
                last_acf_amp      = ar.amplitude_deg;
                last_acf_be       = ar.beat_error_ms;
                last_acf_beats    = ar.beats_used;
            }
            samples_since_last_acf = 0;
        }

        pos += k;
    }
    /* Drain delay line */
    tg_result_t rf;
    tg_flush(tg, &rf);
    if (rf.processed_pcm_len > 0) {
        fwrite(rf.processed_pcm, sizeof(float), rf.processed_pcm_len, fenv);
    }
    size_t n_an = tga_analyze(an, rf.events, rf.num_events,
                              analyzed_events, 256);
    for (size_t i = 0; i < n_an; i++) {
        tga_event_t *e = &analyzed_events[i];
        fprintf(fe, "%.6f,%c,%.6f,%.2f\n",
                e->time_seconds,
                e->type == TG_EVENT_A ? 'A' : 'C',
                e->peak_value, e->amplitude_deg);
        if (e->type == TG_EVENT_A) A_count++;
        if (e->type == TG_EVENT_C) {
            C_count++;
            if (e->amplitude_valid) { pair_count++; amp_sum += e->amplitude_deg; }
        }
    }
    fclose(fe);
    fclose(fenv);

    double mean_amp = (pair_count > 0) ? amp_sum / pair_count : 0;
    printf("detected_bph=%d A=%d C=%d per-event-amp=%.1f (%d pairs) "
           "acf: period=%.6fs amp=%.1f beat_err=%.2fms (%d beats)\n",
           detected_bph, A_count, C_count, mean_amp, pair_count,
           last_acf_period_s, last_acf_amp, last_acf_be, last_acf_beats);

    tgacf_destroy(acf);
    tga_destroy(an);
    tg_destroy(tg);
    free(pcm);
    return 0;
}
