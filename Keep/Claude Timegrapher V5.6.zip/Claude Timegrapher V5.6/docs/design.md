# Claude Timegrapher V5.0 - Design and Theory

This document explains the algorithms used in libtimegrapher, libtgan,
and libtgacf, and the rationale behind each design choice.

For API reference and usage examples, see `api.md`.

## 1. Architecture

V5.0 splits the system into three independent libraries:

| Library         | Role                                              |
|-----------------|---------------------------------------------------|
| libtimegrapher  | Detection: PCM -> A/C event timestamps            |
| libtgan         | Analytics: events -> per-event amplitude, gate    |
| libtgacf        | Analytics: envelope+events -> period, amp, BE     |

The detection layer is **stateful streaming**: it processes audio
chunk-by-chunk and emits events as they're recognized. The analytics
layers are **stateful post-processors**: they consume the events
produced by detection and derive measurements.

The split honors a real distinction: detection is irreversible (audio
is lossy-compressed into events; you can't recompute events with
different parameters once the audio is gone), while analytics is
re-runnable (the same event stream can be analyzed under different
config without re-processing audio).

## 2. Signal chain (libtimegrapher)

```
PCM (float32 mono)
  -> tg_hpf:       single-pole HPF (200 Hz default)
  -> tg_envelope:  full-wave rectify + 0.15 ms one-pole LPF
  -> [delay line: 50 ms]
  -> tg_detector:  silence-based onset, A and C with sub-sample timing
  -> tg_bph:       Rayleigh phase-score period detection
  -> tg_sync:      PLL tracker
```

### 2.1 Why a single-pole HPF, not a bandpass?

Watch ticks contain energy from a few hundred Hz up to several kHz, with
species-specific spectra (escapement design, case material, microphone
coupling). Bandpass filters tuned to one watch's resonances will
attenuate ticks from another. The single-pole 200 Hz HPF removes only
LF rumble (HVAC, speech, mains hum) while preserving the full tick
spectrum. Threshold-based detection then handles the wide variation.

### 2.2 Envelope extraction

`abs(x) + 0.15 ms one-pole LPF`. Full-wave rectification turns a
bipolar tick into a unipolar pulse; the LPF smooths sample-to-sample
ripple from the carrier inside the tick. 0.15 ms is short enough to
preserve the impulse onset within ~1 sample at 48 kHz, and long
enough to merge sub-sample oscillations.

### 2.3 Envelope delay line

The user-facing `processed_pcm` lags the input by 50 ms. This serves
two purposes:

1. **Event/PCM alignment**: events emitted from `tg_process()` carry
   absolute sample indices in the input stream. The corresponding
   peak in `processed_pcm` is at `event.sample_index -
   result.processed_pcm_start_sample` within the buffer. The delay
   ensures that for any event in the current block, the corresponding
   PCM sample is also in the current block.

2. **End-of-burst tail**: the silence-based detector requires a wall-
   clock silence after a burst before declaring it ended. Without
   the delay, that decision could only be made after seeing future
   samples. With the delay, the detector reads the un-delayed
   envelope (which is "ahead" of the user-visible PCM by 50 ms),
   so it has 50 ms of look-ahead.

50 ms is fixed (not BPH-dependent) so it doesn't glitch when sync
locks/unlocks.

## 3. Detector (libtimegrapher/Detector.cpp)

### 3.1 Adaptive thresholds

Two thresholds are tracked:

- **noise_floor**: 75th percentile of a 256-slot ring buffer of
  decimated silence samples (1 sample/ms).
- **reference_peak**: median of the last 16 accepted burst peaks.

Two derived gates:

- **onset_threshold** = noise + onset_fraction * (reference_peak - noise)
- **min_peak_threshold** = noise + min_peak_fraction * (reference_peak - noise)

Defaults: onset_fraction = 0.03, min_peak_fraction = 0.20.

The onset_threshold triggers entry into a "burst" state when the
envelope rises above it. The min_peak_threshold filters out bursts
whose maximum is below 20% of the reference peak (these are usually
echoes or environmental noise).

The percentile and median structures make the thresholds **scale-
invariant**: a watch recorded at -20 dBFS produces the same event
stream as the same watch at -6 dBFS, because both numerator and
denominator of the threshold ratio scale together.

### 3.2 Wall-clock silence gate vs. continuous-below-threshold

A naive end-of-burst gate would watch for the envelope to dip below
threshold, but high-Q watches ring after each tick, and the envelope
oscillates above and below threshold for many ms. The detector instead
uses a **wall-clock silence gate**: once a burst has ended, a fresh
onset can fire only after `min_silence_samples` of wall-clock time has
elapsed since the burst-end declaration.

Pre-sync: `min_silence_samples` defaults to 20 ms (loose enough to
catch any reasonable BPH). Once sync locks: tightened to 40% of the
beat period.

### 3.3 A-to-A interval gate (V4.5 addition)

For watches with multi-impulse beats (vintage Walthams, dirty
escapements, recordings with case reverberation), the wall-clock
silence gate isn't enough. Sub-impulses inside one beat-cluster can
produce multiple onsets, each separated by 20-40 ms but all within a
single ~200 ms beat.

The A-to-A interval gate is a third condition: a new A onset can fire
only if `samples_since_last_a >= min_a_interval_samples` (in addition
to threshold and silence-gate). Pre-sync this is 0 (so BPH detection
sees all candidate events). Post-sync, it's 70% of beat period.

The counter `samples_since_last_a` resets only when an A is
**successfully emitted** (passes both onset and min-peak gates),
not on every threshold crossing.

### 3.4 Sub-sample timing

**A events** use linear interpolation across the threshold crossing:
the onset is at the time `t = (sample_at_or_before) + frac` where
`frac = (onset_thr - prev) / (current - prev)`. This is exact for a
linear function near the threshold.

**C events** use parabolic interpolation at the burst maximum:
given three samples `y_-1, y_0, y_+1` straddling the maximum,
fit a parabola; vertex offset is `0.5 * (y_-1 - y_+1) / (y_-1 - 2*y_0 + y_+1)`.
This is exact for a parabolic peak (the typical envelope shape near
the local maximum) and gives sub-sample accuracy without iteration.

### 3.5 C-search skip window (V5.2 addition)

The naive approach to placing C is "the highest envelope sample
within the burst". This works on clean recordings where the C cluster
is the dominant feature. It fails on multi-impulse watches where the
A's own impulse spike, or an intermediate sub-impulse, can occasionally
exceed the height of the actual C cluster:

```
envelope:    /\___/\___/\\\\\___          <- A spike, then a hump,
                                              then real C cluster
burst_max:   ^                            <- could be here (wrong)
              or            ^             <- or here (also wrong)
              or                     ^    <- ideally here (correct)
```

The detector tracks the C-peak **separately** from `burst_max`, only
considering envelope samples past a configurable `c_search_skip_samples`
counted from burst start. `burst_max` itself is unchanged and is still
used for the min-peak height check at burst-end. If no peak appears
past the skip window (very short bursts), C falls back to
`burst_max_idx` for backward compatibility.

The skip width is set by the library at sync acquisition to **3% of
the beat period**. This is short enough to leave a safe margin below
`t_AC` even at knocking amplitude (~360 deg, where t_AC is shortest),
and long enough to skip past common intermediate sub-impulses:

| BPH   | Period | Skip   | t_AC at 360 deg (lift 50) |
|-------|--------|--------|---------------------------|
| 18000 | 200 ms | 6.0 ms | 9.2 ms                    |
| 21600 | 167 ms | 5.0 ms | 7.4 ms                    |
| 28800 | 125 ms | 3.8 ms | 5.7 ms                    |
| 36000 | 100 ms | 3.0 ms | 4.6 ms                    |

Pre-sync the skip is the fixed 3 ms default (BPH not yet known).

### 3.6 C-onset detection and placement modes (V5.4 addition)

The C event has historically been emitted at the C cluster's peak —
the envelope maximum after the C-search skip. This matches the
convention used by commercial timegraphers and is what the canonical
amplitude formula expects:

```
amp = (3600 * lift) / (t_AC * pi * BPH)    where t_AC = t_C_peak - t_A_onset
```

The peak is, however, asymmetric: A is measured at its onset (a
threshold-crossing on the rising edge), but C is measured at its
peak. The peak position can shift with amplitude/SNR, pulse shape,
and multi-impulse cluster structure. Threshold-crossing onsets are
generally more stable timing references because they sit on the
envelope's rising edge where slew rate is highest.

V5.4 makes the C-onset available alongside the C-peak. The detector
finds it by walking **backward** from the already-determined C peak:

```
threshold = 0.5 * c_peak_value
walk back from c_peak_idx:
  count consecutive samples where envelope < threshold
  when count >= dwell_samples, declare the most recent
    above-threshold sample the onset
  bound the walk by c_onset_search_max_samples
linear interpolation refines the threshold-crossing to sub-sample
```

Two safeguards keep the walk reliable:

- **dwell** (default 0.3 ms): require this many consecutive
  below-threshold samples before declaring an onset boundary. Without
  this, internal ringing notches inside the C cluster could register
  as onsets.

- **search bound** (default 5 ms): cap the backward walk so it can't
  cross out of the C cluster and into the A-impulse region.

If neither safeguard triggers a clean onset (envelope never dips far
enough or for long enough before the peak), `onset_valid` stays 0 on
the emitted event and downstream falls back to peak.

The detector keeps a small ring buffer of recent envelope samples
(10 ms; ~480 samples at 48 kHz) so the backward walk has data to
consume at burst-emission time.

**Placement modes** (`tg_c_placement_t`):

- `TG_C_PLACEMENT_PEAK` (default): primary timing in `tg_event_t`
  (`time_seconds`, `sample_index`, `sub_sample_offset`) is the C
  peak. Onset is also reported as metadata in the `onset_*` fields
  when found. V5.0–V5.3 behavior preserved exactly.

- `TG_C_PLACEMENT_ONSET`: primary timing is the C onset. Falls back
  to peak if onset detection fails for that beat. Onset is also
  reported in the `onset_*` fields (so consumers can tell whether
  they got onset or fallback by checking `onset_valid`).

Per-event amplitudes (libtgan) and ACF amplitudes (libtgacf)
automatically use whichever timing the placement mode selects. libtgan
reads the primary `time_seconds` from each event and pairs against it
— no per-library setting needed. libtgacf carries its own
`c_placement` config that should be set to match the detector's mode
(`tgacf_set_c_placement` or via `tgacf_config_t`). In practice ONSET
mode produces slightly higher amplitudes than PEAK mode (shorter A→C
gap → higher amplitude in the formula); the shift correlates with
the C cluster's rise time.

### 3.7 Regime-change reset (V5.6 addition)

The adaptive thresholds described in 3.1 work well when the audio
stream presents one consistent acoustic regime — silence followed
shortly by watch ticks. They fail when the stream begins with an
extended quiet prelude that contains intermittent low-level noise
(fan hum, mic handling, ambient bumps) followed by the watch
arriving on the microphone many seconds later.

What goes wrong:
- The 75th-percentile noise floor settles on the genuine silence
  floor (e.g. 0.0002) between noise bursts.
- The 16-slot median burst peak ring fills with tiny pre-signal
  "bursts" (0.0005–0.001), making the adaptive threshold extremely
  sensitive.
- The 256-slot event history buffer fills with hundreds of spurious
  events at random times. The Rayleigh phase-score can't lock on
  the real signal until those events flush out, which can take
  tens of seconds at 21600 BPH.
- The detector's median ref_peak has to climb from ~0.0005 to the
  real watch level (~0.05–0.1) — two orders of magnitude — pulled
  by the median of only 16 most-recent peaks. Slow.

The combined effect: a recording with 10 seconds of quiet prelude
followed by 30 seconds of normal watch signal might not produce
the first amplitude pair until 35+ seconds in.

**Algorithm.** The detector maintains a short ring of 8 recent
burst peak values (separate from the 16-slot peak_history). When
a new peak arrives that's `>= 10 × min(ring) AND both values are
above 0.001`, the regime has changed and the detector sets a flag
that the library checks after each block.

On a flagged change:
1. The library flushes the polluted state: event history, sync
   state and PLL internals, cached BPH/period/AC-offset, the
   detector's peak_history and noise_history rings.
2. The detector's **sample clock and env_ring abs-index reference**
   are preserved across the reset so absolute timestamps stay
   continuous and the C-onset backward walk continues to work.
3. The regime ring is re-seeded with the triggering peak value
   so the next beat doesn't immediately re-trigger.
4. A one-shot `tg_result_t.detector_reset_event` flag is surfaced
   so the caller can react (e.g. flush their own analytics).

**Cooldown.** Only one reset per 1 second of audio. Prevents a
series of consecutive loud impulses (mic handling transients,
fade-in) from each triggering their own reset and preventing sync
from settling.

**Why 10× and not larger.** A watch arriving on a microphone
typically jumps 50–500× from ambient noise. A real watch knock
or bump mid-recording is usually 2–3× the running peak. 10× is
high enough to ignore knocks but low enough to catch even quiet
movements coming out of moderate ambient noise.

**Trade-offs.** This adds one ring buffer (8 doubles), one
comparator per accepted peak, and a flag check per block. No
measurable cost. The risk is mid-recording false triggers on
genuinely loud beats; the 10× threshold and absolute floor of
0.001 keep this rare on real watch recordings (verified against
all 11 reference recordings).

## 4. BPH detection (libtimegrapher/Bph.cpp)

### 4.1 Rayleigh phase-score

For a candidate beat period T and a list of N event times t_i, compute:

```
phase_i = 2*pi * (t_i mod T) / T
score   = | (1/N) * sum_i exp(j * phase_i) |
```

This is the magnitude of the Rayleigh "circular mean" of the phases.
If events are uniformly distributed mod T (random/no relationship),
score approaches 0. If they all cluster at one phase (perfect lock),
score approaches 1.

The library tries each candidate BPH from `TG_AUTO_BPH_LIST` and picks
the one with the highest score, requiring `score >= 0.7` for lock.

### 4.2 Period/half-period aliasing and the median guard

The first-harmonic Rayleigh score has an aliasing weakness: for
perfectly periodic events, R1 at the true period equals R1 at any
integer fraction (T/2, T/3, ...) — all give score = 1.0. In practice
the events have small jitter, so R1 at T is slightly higher than at
T/2, but the difference can be smaller than the BPH list spacing.

This caused 18000 BPH watches with intermittent secondary echoes
(small aftershock impulses ~50 ms after each main beat, common on
vintage / multi-impulse movements) to be mis-detected as 36000 BPH
in V5.0-V5.2.

V5.3 adds a **physical lower bound**: compute the median A-to-A
interval and reject any candidate period less than 0.7 * median.
The median A-to-A is a robust lower bound on the true beat period
(spurious extra events can only make consecutive A-to-A intervals
smaller, never larger than the true beat period). This breaks the
period/half-period aliasing without affecting any other case.

### 4.3 Why phase-score over period-histograms?

Period histograms (look at A-to-A gaps, find the most common one)
work well on clean signals but fail on:
- Multi-impulse watches where most "intervals" are sub-impulse gaps
- Recordings with sync loss / re-acquisition (mixed periods in history)

Phase-scoring is robust to these because it doesn't care about
adjacent-event structure - only how events distribute in phase
relative to a hypothetical period.

## 5. PLL sync tracker (libtimegrapher/Bph.cpp)

Once locked, a single-pole tracker maintains `next_a_time` and
`beat_period`:

```
phase_error = event_time - next_a_time         (signed)
beat_period += pll_period_gain * phase_error    (default gain 0.01)
next_a_time = event_time + beat_period
```

If `|phase_error|` exceeds `sync_tolerance_pct * beat_period` for
`sync_loss_misses` consecutive events, sync is declared lost.

Default loss threshold: 12 missed beats. Tighter values (e.g., 4)
make the tracker more sensitive to brief disturbances; looser values
(e.g., 24) ride through long noise bursts.

## 6. Amplitude pairing (libtgan)

### 6.1 Industry amplitude formula

```
amp = (3600 * lift_angle_deg) / (t_AC * pi * BPH)
```

`t_AC` is the time from A (escape unlock) to C (drop/lock) - the
duration of the impulse phase. `lift_angle_deg` is the watch-specific
balance angular sweep during impulse (typical 38-60 degrees).

This is the "Witschi formula" used by all commercial timegraphers.
It assumes the impulse is symmetric and the balance velocity through
impulse is constant - both approximations valid to ~1% for healthy
watches.

### 6.2 Physics-derived A->C pairing window (V4.4 addition)

The previous "pair if dt < 0.5 * beat_period" rule could pair events
across noise gaps and produce 700+ degree "amplitudes". V4.4
constrains pairing to physically possible intervals:

```
t_AC_min = (3600 * lift) / (pair_amp_max * pi * BPH)
t_AC_max = (3600 * lift) / (pair_amp_min * pi * BPH)
```

Defaults: pair_amp_min = 80, pair_amp_max = 400. Generous enough to
cover low-amplitude vintage watches (80-180 deg), modern healthy
ranges (220-310 deg), knocking pathology (320-360 deg), and lift-angle
uncertainty (a 20% mis-entered lift shifts t_AC by 20%).

For 18000 BPH, lift=50: t_AC window is 5.7-28.6 ms.
For 21600 BPH, lift=50: t_AC window is 4.7-23.9 ms.
For 28800 BPH, lift=52: t_AC window is 3.7-18.6 ms.

Out-of-window candidates: events still emit (timing preserved),
amplitude_deg = 0, amplitude_valid = 0.

## 7. Predicted-time gate (libtgan)

### 7.1 Pascal Chour's "occultation window"

Pascal Chour's PC-RM3/RM4 designs validate each tick against an
expected time, accepting only pulses within a configurable fraction
of the half-period. V5 generalizes this:

- **TGA_GATE_OFF**: no temporal validation
- **LOOSE**: +-25% of beat period
- **MEDIUM**: +-15% of beat period
- **TIGHT**: +-7% of beat period
- **CUSTOM**: user-specified [0.01, 0.45]

### 7.2 Phase reference and tracking

After sync acquisition, the analyzer takes the sync-event time as
the phase reference. Every subsequent A is predicted at:

```
predicted_time = phase_ref + k * beat_period   (k = 0, 1, 2, ...)
```

C events inherit the gate decision of their preceding A, with
`predicted_time = A.predicted_time + (C.actual - A.actual)`.

The phase reference drifts gently with each in-window event:

```
observed_phase = event.time - k * beat_period
phase_ref += 0.05 * (observed_phase - phase_ref)
```

Gain 0.05 is a ~20-event time constant - fast enough to follow PLL
drift, slow enough to ignore single-event noise. Out-of-window events
do NOT pull the reference (they could pull it further off-grid).

### 7.3 Tic/toc parity

`parity = phase_event_count & 1`. Even-indexed beats are "tic"
(parity=0), odd are "toc" (parity=1). Each pallet stone produces one
beat per oscillation, so consecutive beats correspond to opposite
stones. Asymmetric impulse geometry shows up as a per-parity timing
offset (the standard "two-trace" timegrapher display).

## 8. Autocorrelation (libtgacf)

### 8.1 Period refinement

For a window of `win_samples` envelope samples, compute the ACF:

```
r(k) = sum_{i=0..win-1} env[i] * env[i + k]
```

Search `k` in a narrow range +-3% around the expected period (in
samples). Find the `k` with maximum `r(k)`, then parabolic-interpolate
to sub-sample accuracy using `r(k-1), r(k), r(k+1)`.

This is **rate-limited** - typical implementation runs the estimate
once per second of audio (the window is ~2 seconds, so consecutive
estimates would mostly re-use the same data).

### 8.2 Aligned-median amplitude

For each recent A event, extract a window of one beat period and find
the envelope maximum (which is the C). The A->C gap is `peak_offset`.
**Median across many beats** gives a robust amplitude estimate, more
stable than per-event amplitude (which depends on the timing of one
A and one C, both of which are ~1 sample noisy).

### 8.3 Beat error from A-to-A interval asymmetry

In a watch that's "in beat", the balance is centered between the two
pallet stones at rest, so consecutive A-to-A intervals are equal
(= beat_period). When the balance is "out of beat", the unlock fires
earlier on one side and later on the other, producing alternating
long/short A-to-A intervals.

Compute median A-to-A interval separately for the two parities:

```
beat_error_ms = 0.5 * 1000 * |median(long_AA) - median(short_AA)|
```

The 0.5 factor matches the canonical timegrapher convention
(half-difference, not full difference). For the synthetic test
streams `Be6_0` (6 ms encoded) and `Be9_9` (9.9 ms encoded), the
ACF reads back the encoded value to 0.00 ms precision.

A beat error > 1-2 ms typically indicates the watch needs a beat
adjustment (the hairspring stud needs rotation to center the balance
between the two pallet stones at rest).

**Note**: the V4.x and V5.0 implementations measured beat error from
**A->C gap asymmetry** (impulse-duration difference) instead of
A-to-A interval asymmetry. V5.1 corrected this to match the standard
timegrapher convention. A->C gap asymmetry is a different defect
(worn or asymmetric pallet stones) and is not what users mean when
they say "beat error".

## 9. Tradeoffs and design choices

### 9.1 Per-event vs. window-averaged amplitude

The library exposes both:

- **Per-event** (libtgan): one number per beat, can show drift over
  time, sensitive to single-event timing noise (~+-3 deg jitter).
- **Window-averaged** (libtgacf): one number per second, smoother,
  hides single-beat anomalies.

Both are useful for different purposes. UIs typically display the
window-averaged value as the headline reading and per-event values
as a scatter plot.

### 9.2 Defer or compute-now

The library performs detection inline (per-block), but rate-limits
ACF analytics. This trades some latency in the ACF readout (~1 sec)
for predictable per-block CPU cost.

### 9.3 Stateful vs. functional analytics

libtgan and libtgacf are stateful (track phase, pending A, rolling
buffer). They could be functional (take all events, return all
analytics) but that costs O(N) memory per call and re-computes on
every analytic readout. The streaming-stateful design matches the
streaming detection upstream.

## 10. References

- Pascal Chour: PC-RM3/RM4 designs and "occultation window" approach,
  https://www.pascalchour.fr/mesures/
- vacaboja/tg: open-source FFT-based watch analyzer,
  https://github.com/vacaboja/tg
- Witschi/Watch Repair tools: amplitude formula derivation,
  industry-standard impulse-time-to-amplitude conversion.
- NAWCC discussions on lift angle and beat error semantics.
- pocketwatchdatabase.com: lift-angle reference for vintage watches.
