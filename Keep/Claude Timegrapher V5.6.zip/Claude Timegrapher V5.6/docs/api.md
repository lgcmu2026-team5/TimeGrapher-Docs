# Claude Timegrapher V5.0 - API Reference

For the algorithms and theory behind these APIs, see `design.md`.

## Quick start

V5.0 splits the system into three independent libraries. A typical
user pipeline uses all three:

```c
#include "Timegrapher.h"
#include "Tgan.h"
#include "Tgacf.h"

/* Setup */
tg_config_t  tg_cfg;  tg_config_default(&tg_cfg);
tga_config_t an_cfg;  tga_config_default(&an_cfg);
tgacf_config_t acf_cfg; tgacf_config_default(&acf_cfg);

tg_cfg.sample_rate = 48000.0;
an_cfg.lift_angle_deg = 52.0;
acf_cfg.sample_rate = 48000.0;

tg_context_t      *tg  = tg_init(&tg_cfg);
tga_analyzer_t    *an  = tga_create(&an_cfg);
tgacf_estimator_t *acf = tgacf_create(&acf_cfg);

/* Streaming */
while (have_audio) {
    tg_result_t r;
    tg_process(tg, pcm, num_samples, &r);

    /* Push delayed envelope to ACF estimator. */
    if (r.processed_pcm_len > 0) {
        tgacf_push_envelope(acf, r.processed_pcm,
                            r.processed_pcm_len,
                            r.processed_pcm_start_sample);
    }

    /* Notify analyzer about sync transitions. */
    if (r.sync_acquired_event) {
        tga_update_period(an, r.measured_period_s);
        for (size_t i = 0; i < r.num_events; i++) {
            if (r.events[i].type == TG_EVENT_A &&
                !r.events[i].is_pre_sync) {
                tga_notify_sync_acquired(an, r.events[i].time_seconds);
                break;
            }
        }
    }
    if (r.sync_lost_event) tga_notify_sync_lost(an);
    if (r.sync_status == TG_SYNC_SYNCED && r.measured_period_s > 0) {
        tga_update_period(an, r.measured_period_s);
    }

    /* Run analytics. */
    tga_event_t analyzed[256];
    size_t n = tga_analyze(an, r.events, r.num_events, analyzed, 256);
    for (size_t i = 0; i < n; i++) {
        if (analyzed[i].type == TG_EVENT_A)
            tgacf_push_a_event(acf, analyzed[i].time_seconds);

        /* Use analyzed[i].amplitude_deg, predicted_time_seconds, etc. */
    }

    /* Optional rolling readout (rate-limit to once per second!). */
    static uint64_t samples_since_last = 0;
    samples_since_last += num_samples;
    if (samples_since_last >= 48000 && r.sync_status == TG_SYNC_SYNCED) {
        tgacf_result_t ar;
        if (tgacf_estimate(acf, r.measured_period_s, 52.0, &ar)) {
            /* ar.period_s, ar.amplitude_deg, ar.beat_error_ms,
             * ar.beats_used */
        }
        samples_since_last = 0;
    }
}

/* Drain. */
tg_result_t rf;
tg_flush(tg, &rf);
/* ... process rf.events as above ... */

tgacf_destroy(acf);
tga_destroy(an);
tg_destroy(tg);
```

## libtimegrapher: detection

### `tg_config_t`

```c
typedef struct {
    double         sample_rate;        /* Hz, e.g. 48000 (required)   */
    tg_bph_mode_t  bph_mode;           /* AUTO or MANUAL              */
    int            manual_bph;         /* required when MANUAL        */

    /* Optional - 0 = library default */
    double  hpf_cutoff_hz;             /* default 200.0               */
    double  envelope_smooth_ms;        /* default 0.15                */
    double  event_min_separation_ms;   /* refractory, default 2.0     */
    double  sync_tolerance_pct;        /* default 3.0                 */
    double  auto_detect_seconds;       /* default 1.5                 */
    int     sync_loss_misses;          /* default 12                  */
    double  pll_period_gain;           /* default 0.01                */
    double  pll_ac_gain;               /* default 0.05                */

    double  onset_fraction_init;       /* 0 -> 0.03                   */
    double  min_peak_fraction_init;    /* 0 -> 0.20                   */

    int     suppress_pre_sync_events;  /* drop pre-sync events        */
} tg_config_t;
```

#### Parameters

- **`sample_rate`**: Audio sample rate in Hz. Required. Library
  supports 48000-384000.
- **`bph_mode`**:
  - `TG_BPH_MODE_AUTO`: Try BPHs from `TG_AUTO_BPH_LIST` (12000,
    14400, 18000, 19800, 21600, 25200, 28800, 36000, 43200) and
    pick the best match.
  - `TG_BPH_MODE_MANUAL`: Use `manual_bph`. Library validates the
    signal matches and sets `sync_status = TG_SYNC_MISMATCH`
    if not.
- **`hpf_cutoff_hz`**: Single-pole HPF cutoff, removes LF rumble.
  Default 200 Hz works for most setups. Lower (50 Hz) preserves
  more body resonance; higher (500 Hz) rejects more rumble at
  the cost of some tick character.
- **`envelope_smooth_ms`**: One-pole LPF time constant on the
  rectified signal. 0.15 ms = ~1 sample at 48 kHz, sharp envelope.
  Larger values (0.5 ms) smooth more.
- **`onset_fraction_init`**, **`min_peak_fraction_init`**:
  Detector threshold tuning, expressed as fractions of the noise-
  to-reference-peak dynamic range. Defaults 0.03 / 0.20 work for
  most clean recordings. For noisy recordings (vintage watches,
  strong room reverb), raise both to 0.10 / 0.50 to suppress
  sub-impulse noise.
- **`sync_tolerance_pct`**: After sync, how far an event can stray
  from the predicted grid (as % of period) before counting as a
  miss. Default 3% (e.g., +-5 ms at 21600 BPH).
- **`auto_detect_seconds`**: How much event history is needed
  before the first BPH detection attempt. Default 1.5 s.
- **`sync_loss_misses`**: Consecutive missed beats before declaring
  sync lost. Default 12.
- **`pll_period_gain`**, **`pll_ac_gain`**: PLL gains for tracking
  long-term drift in beat period and A->C offset. Defaults 0.01
  and 0.05 = ~100-event and ~20-event time constants.

### `tg_event_t`

```c
typedef struct {
    /* Primary timing (chosen per c_placement for C events; for A
     * events this is always the onset). */
    double           time_seconds;
    uint64_t         sample_index;
    double           sub_sample_offset;
    float            peak_value;
    tg_event_type_t  type;             /* TG_EVENT_A or TG_EVENT_C */
    int              is_pre_sync;

    /* V5.4: C-event onset metadata. Always populated for C events
     * when the backward-walk algorithm finds the C cluster's rising
     * edge; zero / 0 for A events and for C events where onset
     * detection failed. */
    uint64_t         onset_sample_index;
    double           onset_sub_sample_offset;
    double           onset_time_seconds;
    int              onset_valid;
} tg_event_t;
```

- **`time_seconds`**: Absolute time of event in the input stream
  (sub-sample accurate).
- **`sample_index`**: Integer sample index in the input stream.
- **`sub_sample_offset`**: Fractional refinement, in [-0.5, +0.5].
  `time_seconds == (sample_index + sub_sample_offset) / sample_rate`.
- **`peak_value`**: Envelope value at the event location. For C
  events on multi-impulse watches this is the burst maximum, which
  may be slightly higher than the envelope value at the C peak
  itself (the burst max can be in the A spike; C is then placed
  later at a smaller local peak).
- **`type`**: `TG_EVENT_A` (unlock) or `TG_EVENT_C` (drop/lock).
- **`is_pre_sync`**: 1 if emitted before BPH lock acquired.
- **`onset_sample_index`** / **`onset_sub_sample_offset`** /
  **`onset_time_seconds`** (V5.4): for C events, the rising-edge
  half-height crossing of the C cluster (always populated when found,
  regardless of placement mode). For A events these are 0.
- **`onset_valid`** (V5.4): 1 if the onset_* fields are populated.

#### C-event placement on multi-impulse watches (V5.2)

The detector tracks the C-peak separately from the burst maximum,
considering only envelope samples past a small skip window from
burst start. This rejects the A's own impulse spike and intermediate
sub-impulses from being mis-placed as C. The skip is tuned to BPH
once sync acquires (3% of beat period: 5 ms at 21600 BPH, 3.75 ms at
28800 BPH). Pre-sync the skip is 3 ms. See `docs/design.md` section
3.5 for details.

#### C-event placement modes (V5.4)

The detector exposes a runtime mode that controls which C timing
populates the primary fields of `tg_event_t`:

```c
typedef enum {
    TG_C_PLACEMENT_PEAK  = 0,   /* default: V5.0-V5.3 behavior */
    TG_C_PLACEMENT_ONSET = 1
} tg_c_placement_t;
```

The full behavior across modes for a C event:

| Field                         | `PEAK` mode (default)     | `ONSET` mode               |
|-------------------------------|---------------------------|----------------------------|
| `time_seconds`                | C peak                    | C onset (peak fallback)    |
| `sample_index`                | peak's integer index      | onset's integer index      |
| `sub_sample_offset`           | peak's fraction           | onset's fraction           |
| `peak_value`                  | envelope value at peak    | envelope value at peak     |
| `onset_time_seconds`          | C onset                   | C onset                    |
| `onset_sample_index`          | onset's integer index     | onset's integer index      |
| `onset_sub_sample_offset`     | onset's fraction          | onset's fraction           |
| `onset_valid`                 | 1 when found              | 1 when found               |

Two key invariants:

1. **The `onset_*` trio is populated identically in both modes** (when
   the backward-walk succeeds). The mode does not gate them. Code that
   wants the onset can read these four fields regardless of which
   mode is active.

2. **The mode only changes which timing is "primary."** It moves the
   onset value into the `time_seconds` / `sample_index` /
   `sub_sample_offset` fields, replacing the peak. In `ONSET` mode
   the peak is no longer reported anywhere (only the value at peak,
   `peak_value`, survives — its timing is lost).

The same redundant-trio identity holds for both timings:

```
time_seconds       == (sample_index       + sub_sample_offset)       / sample_rate
onset_time_seconds == (onset_sample_index + onset_sub_sample_offset) / sample_rate
```

If onset detection fails for a beat (`onset_valid == 0`), in `ONSET`
mode the primary fields fall back to peak. The fallback is silent;
detect it by checking `onset_valid`.

Set via `tg_set_c_placement(ctx, mode)` at runtime, or via
`tg_config_t.c_placement` at init. The mode primarily affects libtgan
(which reads `time_seconds` for its amplitude calculation and
auto-follows whichever timing the detector emitted).

libtgacf carries an independent `c_placement` field — set it to match
the detector with `tgacf_set_c_placement(acf, mode)` if you want the
ACF amplitude readout to use the same timing convention. See
`docs/design.md` section 3.6 for the algorithm.

### `tg_result_t`

```c
typedef struct {
    tg_sync_status_t  sync_status;
    int               detected_bph;
    double            measured_period_s;

    tg_event_t       *events;
    size_t            num_events;

    float            *processed_pcm;
    size_t            processed_pcm_len;
    uint64_t          processed_pcm_start_sample;

    int               sync_lost_event;
    int               sync_acquired_event;
    /* V5.6: one-shot flag set when the regime-change detector
     * flushed adaptive state due to a >= 10x amplitude jump. */
    int               detector_reset_event;

    float             onset_threshold;
    float             min_peak_threshold;
    float             noise_floor;
    float             reference_peak;
} tg_result_t;
```

- **`events`**, **`num_events`**: Events emitted in this call. Pointer
  is owned by the context; valid until next `tg_process`/`tg_flush`/
  `tg_destroy`.
- **`processed_pcm`**: Delayed envelope, aligned with events.
  `processed_pcm[i]` corresponds to absolute sample index
  `processed_pcm_start_sample + i`. Useful for plotting.
- **`sync_acquired_event`** / **`sync_lost_event`**: One-shot edge
  flags fired in the call where the transition happened.
- **`detector_reset_event`** (V5.6): One-shot edge flag set when
  the regime-change detector flushed adaptive state (event history,
  sync, noise floor, peak median). Typically fires once near the
  start of recordings that have a long quiet prelude followed by
  the watch arriving on the microphone. See `docs/design.md`
  section 3.7. Callers that maintain their own analytics (e.g.
  libtgan/libtgacf instances, custom UI state) may want to flush
  in sync. The library does NOT call `tga_notify_sync_lost` on the
  downstream analyzer when this fires -- the event stream just
  resumes from cleaner state.

### Functions

- `tg_context_t *tg_init(const tg_config_t *cfg)`
- `void tg_destroy(tg_context_t *ctx)`
- `int  tg_process(tg_context_t *ctx, const float *pcm,
                   size_t num_samples, tg_result_t *result)`
- `int  tg_flush  (tg_context_t *ctx, tg_result_t *result)`: Drain
  the envelope delay line at end-of-stream.
- `void tg_reset  (tg_context_t *ctx)`: Clear state, preserve config.
- `void tg_config_default(tg_config_t *cfg)`: Populate with library
  defaults.

### Runtime threshold tuning

```c
double tg_get_onset_fraction   (const tg_context_t *ctx);
double tg_get_min_peak_fraction(const tg_context_t *ctx);
void   tg_set_onset_fraction   (tg_context_t *ctx, double frac);
void   tg_set_min_peak_fraction(tg_context_t *ctx, double frac);
```

Adjusts thresholds at runtime. Clamped to [0.001, 0.9]. Useful for
adaptive UIs that let the user dial sensitivity.

### Runtime C-placement control (V5.4)

```c
tg_c_placement_t tg_get_c_placement(const tg_context_t *ctx);
void             tg_set_c_placement(tg_context_t *ctx, tg_c_placement_t mode);
```

Switches whether the primary timing fields on emitted C events carry
the C peak (`TG_C_PLACEMENT_PEAK`, default) or the C onset
(`TG_C_PLACEMENT_ONSET`). Onset metadata is populated regardless.
Effective on the next burst.

When using libtgacf, mirror the same setting with
`tgacf_set_c_placement(acf, mode)` so both libraries use a consistent
amplitude convention. libtgan picks up the mode automatically — it
reads whichever timing the detector emitted in `time_seconds`, so no
parallel setter is needed there.

## libtgan: amplitude + gate

### `tga_config_t`

```c
typedef struct {
    double  bph;
    double  beat_period_s;       /* = 3600/BPH                       */
    double  lift_angle_deg;      /* watch-specific (e.g. 50, 52)     */

    double  pairing_amp_min;     /* 0 -> default 80                  */
    double  pairing_amp_max;     /* 0 -> default 400                 */

    double  amplitude_min_deg;   /* 0 -> default 100                 */
    double  amplitude_max_deg;   /* 0 -> default 400                 */

    tga_gate_t  gate;            /* default TGA_GATE_OFF             */
    double      custom_window_pct;

    int         suppress_out_of_window_events;
} tga_config_t;
```

- **`bph`**, **`beat_period_s`**: Required for amplitude calculation
  and predicted-time gate. Typically driven from `tg_result_t.
  measured_period_s` via `tga_update_period()`.
- **`lift_angle_deg`**: Watch-specific. Common values: 38-44 for
  vintage pocket watches; 49-52 for modern automatic movements;
  53 for some Japanese movements.
- **`pairing_amp_min`** / **`pairing_amp_max`**: Defines the A->C
  gap window for pairing. Defaults 80 / 400 deg are generous;
  raise pairing_amp_min to be stricter, lower to admit lower-
  amplitude beats.
- **`amplitude_min_deg`** / **`amplitude_max_deg`**: Display range
  gate. Computed amplitudes outside this range have
  `amplitude_valid = 0`. Affects display, not pairing.
- **`gate`**: Predicted-time gate strictness:
  - `TGA_GATE_OFF` (default): no gate
  - `TGA_GATE_LOOSE`: +-25% of beat period
  - `TGA_GATE_MEDIUM`: +-15%
  - `TGA_GATE_TIGHT`: +-7%
  - `TGA_GATE_CUSTOM`: use `custom_window_pct` (clamped [0.01, 0.45])

### `tga_event_t`

Mirrors `tg_event_t` plus analytics:

```c
typedef struct {
    /* Mirrored fields */
    double           time_seconds;
    uint64_t         sample_index;
    double           sub_sample_offset;
    float            peak_value;
    tg_event_type_t  type;
    int              is_pre_sync;

    /* Analytics */
    double           amplitude_deg;
    int              amplitude_valid;
    int              is_in_window;
    double           predicted_time_seconds;
    double           timing_error_ms;
    int              parity;            /* 0 = tic, 1 = toc */
    double           grid_deviation_ms;
} tga_event_t;
```

### Functions

- `tga_analyzer_t *tga_create(const tga_config_t *cfg)`
- `void tga_destroy(tga_analyzer_t *a)`
- `void tga_reset  (tga_analyzer_t *a)`
- `void tga_update_period       (tga_analyzer_t *a, double new_period_s)`
- `void tga_notify_sync_acquired(tga_analyzer_t *a, double sync_event_time)`
- `void tga_notify_sync_lost    (tga_analyzer_t *a)`
- `size_t tga_analyze(tga_analyzer_t *a,
                      const tg_event_t *events, size_t n_in,
                      tga_event_t *out, size_t out_capacity)`
- `void       tga_set_gate(tga_analyzer_t *a, tga_gate_t gate, double window_pct)`
- `tga_gate_t tga_get_gate(const tga_analyzer_t *a)`
- `double     tga_get_window_pct(const tga_analyzer_t *a)`

#### `tga_analyze` semantics

Reads events from `events[0..n_in)`, writes annotated copies to
`out[0..rc)` where `rc <= n_in`. If `out_capacity < n_in`, only the
first `out_capacity` events are written; the rest are dropped (the
function returns `out_capacity`, not `n_in`). Caller can pre-size
`out` to `n_in` to guarantee no drops.

#### Sync notification

The analyzer needs to know when sync acquires (to seed phase
reference) and when it's lost (to invalidate phase). The library
does NOT receive `tg_result_t` directly - the caller relays:

```c
if (r.sync_acquired_event) {
    /* Pick the time of the first non-pre-sync A in this batch */
    double sync_t = 0;
    for (size_t i = 0; i < r.num_events; i++) {
        if (r.events[i].type == TG_EVENT_A && !r.events[i].is_pre_sync) {
            sync_t = r.events[i].time_seconds;
            break;
        }
    }
    if (sync_t > 0) tga_notify_sync_acquired(an, sync_t);
    tga_update_period(an, r.measured_period_s);
}
```

If the caller skips this notification, the analyzer auto-acquires
phase from the first non-pre-sync A event. This works but is
slightly less robust than explicit notification.

## libtgacf: window-averaged readouts

### `tgacf_config_t`

```c
typedef struct {
    double sample_rate;       /* required (Hz)                      */
    double history_seconds;   /* default 3.0                        */
    tg_c_placement_t c_placement;  /* V5.4: default PEAK            */
} tgacf_config_t;
```

The `c_placement` field selects which C timing the ACF amplitude
estimator uses internally:

- `TG_C_PLACEMENT_PEAK` (default): A→C gap is from A onset to the
  envelope max in the search window after A. Matches V5.0–V5.3.
- `TG_C_PLACEMENT_ONSET`: same backward-walk algorithm as the
  detector — find the rising-edge half-height crossing of the C
  cluster and use that for the gap. Mirrors `TG_C_PLACEMENT_ONSET`
  on the detector.

Switch at runtime with `tgacf_set_c_placement(acf, mode)`.

- **`history_seconds`**: How much envelope to keep. 3 seconds is
  enough for ~15 beats at 21600 BPH, ~10 at 36000. Larger values
  smooth ACF readouts; smaller use less memory.

### `tgacf_result_t`

```c
typedef struct {
    double period_s;          /* refined beat period (sub-sample)   */
    double amplitude_deg;     /* aligned-median amplitude           */
    double beat_error_ms;     /* odd vs even pallet timing diff     */
    int    beats_used;        /* number of beats in this estimate   */
    int    valid;             /* 1 = result populated, 0 = no data  */
} tgacf_result_t;
```

### Functions

- `tgacf_estimator_t *tgacf_create (const tgacf_config_t *cfg)`
- `void tgacf_destroy(tgacf_estimator_t *e)`
- `void tgacf_reset  (tgacf_estimator_t *e)`
- `void tgacf_push_envelope(tgacf_estimator_t *e,
                            const float *env, size_t n,
                            uint64_t abs_sample_idx)`
- `void tgacf_push_a_event (tgacf_estimator_t *e, double t_seconds)`
- `int  tgacf_estimate(tgacf_estimator_t *e,
                       double expected_period_s,
                       double lift_angle_deg,
                       tgacf_result_t *out)`

### `tgacf_estimate` is expensive

Each call is O(window_samples * search_range). At 48 kHz with 3 sec
history this is roughly 50 ms wall-time per call. **Rate-limit to
~once per second** of audio:

```c
static uint64_t samples_since_last_acf = 0;
samples_since_last_acf += num_samples;
if (samples_since_last_acf >= 48000) {
    tgacf_estimate(acf, period_s, lift, &ar);
    samples_since_last_acf = 0;
}
```

## Patterns

### Dropping out-of-window events from output

```c
an_cfg.gate = TGA_GATE_MEDIUM;
an_cfg.suppress_out_of_window_events = 1;
```

Events outside the +-15% window are not emitted by `tga_analyze`.

### Manual BPH for known watch

```c
tg_cfg.bph_mode    = TG_BPH_MODE_MANUAL;
tg_cfg.manual_bph  = 18000;
```

Library still verifies the signal matches; if not, sets
`sync_status = TG_SYNC_MISMATCH`.

### Tighten thresholds for noisy recording

```c
tg_cfg.onset_fraction_init    = 0.10;   /* default 0.03 */
tg_cfg.min_peak_fraction_init = 0.50;   /* default 0.20 */
```

Also valid at runtime: `tg_set_min_peak_fraction(ctx, 0.50)`.

### Replay events through a different gate

Once you've captured `tg_event_t`s, you can re-run `tga_analyze`
with different gate config to compare. The library is purely
functional in the events-in events-out sense; only its phase
reference is stateful.

```c
tga_analyzer_t *strict = tga_create(&strict_cfg);
tga_notify_sync_acquired(strict, sync_event_time);
tga_update_period(strict, period_s);
tga_analyze(strict, captured_events, n, strict_results, n);
```

## Versioning

V5.0 is a major version: the API differs from V4.x in that:

- `tg_event_t` no longer carries amplitude or gate fields. Use
  `tga_event_t` from libtgan.
- `tg_result_t` no longer carries ACF readouts. Use `tgacf_result_t`
  from libtgacf.
- Config knobs that controlled analytics (event_gate, pairing_amp_*,
  amplitude_min/max_deg) moved to `tga_config_t`.
- Autocorrelation config and runtime API moved to libtgacf.

V4.x callers can migrate by:
1. Add tga_analyzer_t and tgacf_estimator_t alongside the existing
   tg_context_t.
2. Move analytics config into tga_config_t.
3. After each tg_process(), call tga_analyze() and (rate-limited)
   tgacf_estimate() and consume their outputs in place of V4.x
   per-event/per-result analytics fields.
