/* Tgacf.h - V5.0 autocorrelation-based analytics.
 *
 * Provides a running estimator that maintains a rolling buffer of
 * envelope samples and recent A event times, and on demand computes
 * window-averaged period, amplitude, and beat error.
 *
 * Algorithms:
 *   - Period: ACF peak in a narrow range around expected period;
 *             sub-sample accurate via parabolic interpolation.
 *   - Amplitude: aligned median A->C gap across recent beats, plugged
 *                into the standard amplitude formula.
 *   - Beat error: difference between odd-beat and even-beat A->C
 *                 medians; quantifies pallet asymmetry.
 *
 * Memory: the envelope ring buffer is heap-allocated and sized to hold
 * env_seconds of audio at the configured sample rate (default 3.0 s).
 *
 * Designed to be fed events and envelope from libtimegrapher. The
 * caller pushes envelope blocks AFTER each tg_process() call and the
 * A events from those blocks. tgacf_estimate() can be called whenever
 * a new readout is wanted (typically once per second).
 */
#ifndef TGACF_H
#define TGACF_H

#include <stddef.h>
#include <stdint.h>
#include "Timegrapher.h"   /* for tg_c_placement_t */

#ifdef __cplusplus
extern "C" {
#endif

#define TGACF_EVENT_BUF_N   64

typedef struct {
    double sample_rate;       /* required (Hz)                      */
    double history_seconds;   /* default 3.0                        */

    /* V5.4: which C timing to use when computing amplitude.
     * Default 0 = TG_C_PLACEMENT_PEAK (envelope max in the search
     * window, matching V5.0-V5.3 behavior).
     * TG_C_PLACEMENT_ONSET runs the same backward-walk algorithm
     * as the detector to find the C cluster's rising-edge crossing
     * and uses that for the A->C gap.
     *
     * Mirror this with the detector's c_placement to keep amplitude
     * conventions consistent across libraries. */
    tg_c_placement_t c_placement;
} tgacf_config_t;

typedef struct {
    double period_s;          /* refined beat period (sub-sample)   */
    double amplitude_deg;     /* aligned-median amplitude           */
    double beat_error_ms;     /* odd vs even pallet timing diff     */
    int    beats_used;        /* number of beats in this estimate   */
    int    valid;             /* 1 = result populated, 0 = no data  */
} tgacf_result_t;

typedef struct tgacf_estimator tgacf_estimator_t;

void tgacf_config_default(tgacf_config_t *cfg);

tgacf_estimator_t *tgacf_create (const tgacf_config_t *cfg);
void               tgacf_destroy(tgacf_estimator_t *e);
void               tgacf_reset  (tgacf_estimator_t *e);

/* Push a block of envelope samples. abs_sample_idx is the absolute
 * index (in the caller's stream) of env[0]. Used to position the
 * rolling buffer correctly relative to A event times. */
void tgacf_push_envelope(tgacf_estimator_t *e,
                         const float *env, size_t n,
                         uint64_t abs_sample_idx);

/* Push an A event time (in seconds, absolute). */
void tgacf_push_a_event(tgacf_estimator_t *e, double t_seconds);

/* Compute current readout. Returns 1 on success, 0 if not enough
 * history. expected_period_s is the nominal period (search ±3%). */
int tgacf_estimate(tgacf_estimator_t *e,
                   double expected_period_s,
                   double lift_angle_deg,
                   tgacf_result_t *out);

/* V5.4: runtime placement control (matches tg_set_c_placement). */
tg_c_placement_t tgacf_get_c_placement(const tgacf_estimator_t *e);
void             tgacf_set_c_placement(tgacf_estimator_t *e,
                                       tg_c_placement_t mode);

#ifdef __cplusplus
}
#endif

#endif
