/* Autocorr_internal.cpp -- Window-averaged period and amplitude estimator.
 *
 * See Autocorr_internal.h for the high-level design. In brief, this
 * file provides three readouts each time tg_ac_estimate is called:
 *
 *   1. Period (ACF peak)
 *      Compute r(k) = sum over a sliding window of env[i] * env[i+k]
 *      for k in [-3%, +3%] of the expected period (the lock from the
 *      detector's BPH/PLL gives us a tight prior). Pick the lag with
 *      maximum r and refine to sub-sample with parabolic interpolation
 *      around the peak. The result is the average beat period over
 *      the window -- much more precise than per-event timing because
 *      we integrate over hundreds of thousands of envelope samples.
 *
 *      V5.4 perf: the inner loop was previously calling a wrapper
 *      function with modulo arithmetic 60M+ times per estimate call,
 *      which made tg_dump hang on long recordings. We now copy the
 *      working window into a flat scratch buffer once per estimate;
 *      the inner loop is plain pointer arithmetic. Roughly 10x faster.
 *
 *   2. Amplitude (median A->C gap)
 *      For each recent A event, locate the corresponding C in the
 *      envelope (max of env in the half-period window after A, past
 *      the C-search-skip). Take the median A->C gap, plug it into the
 *      industry-standard amplitude formula. Median is robust to
 *      missed/extra ticks and to occasional anomalous beats.
 *
 *      V5.4 placement: when use_c_onset is set, the same backward-walk
 *      algorithm as the detector (Detector.cpp find_c_onset) finds
 *      the C cluster's rising-edge half-height crossing and uses
 *      that for the gap instead of the peak. Mirrors
 *      TG_C_PLACEMENT_ONSET on the detector.
 *
 *   3. Beat error (odd vs even pallet timing)
 *      Split A-to-A intervals by index parity (i odd vs i even),
 *      take the median of each population, report the half-difference
 *      in milliseconds. A properly-set watch has equal A-to-A
 *      intervals; an out-of-beat watch alternates long/short.
 *
 * V5.5: file renamed from autocorr_internal.c to Autocorr_internal.cpp;
 * compiles under C++17. No algorithmic change. The internal API
 * (tg_ac_init_ex, tg_ac_estimate, etc.) remains C-style (functions
 * operating on a tg_ac_t pointer) so it's straightforward to embed in
 * higher-level test harnesses or research code without dynamic
 * allocation.
 */
#include "Autocorr_internal.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

int tg_ac_init(tg_ac_t *ac, double fs) {
    /* Default: 3 seconds history. Holds ~16 beats at 21600 BPH. */
    return tg_ac_init_ex(ac, fs, 3.0);
}

int tg_ac_init_ex(tg_ac_t *ac, double fs, double env_seconds) {
    if (!ac || fs <= 0.0) return -1;
    if (env_seconds < 2.0) env_seconds = 2.0;

    memset(ac, 0, sizeof(*ac));
    ac->fs = fs;
    ac->env_capacity = (size_t)(env_seconds * fs);
    ac->env = (float*)calloc(ac->env_capacity, sizeof(float));
    if (!ac->env) { ac->env_capacity = 0; return -2; }
    return 0;
}

void tg_ac_destroy(tg_ac_t *ac) {
    if (!ac) return;
    free(ac->env);
    ac->env          = NULL;
    ac->env_capacity = 0;
}

void tg_ac_reset(tg_ac_t *ac) {
    if (ac->env && ac->env_capacity)
        memset(ac->env, 0, ac->env_capacity * sizeof(float));
    ac->env_head_abs_idx = 0;
    ac->env_filled       = 0;
    for (int i = 0; i < TG_AC_EVENT_BUF_N; ++i) ac->a_times[i] = 0.0;
    ac->a_count          = 0;
    ac->a_head           = 0;
    ac->last_period_s    = 0.0;
    ac->last_amp_deg     = 0.0;
    ac->last_beat_error_ms = 0.0;
    ac->last_beats_used  = 0;
}

void tg_ac_push_envelope(tg_ac_t *ac, const float *env, size_t n) {
    if (!ac->env || ac->env_capacity == 0) return;
    for (size_t i = 0; i < n; ++i) {
        size_t slot = (size_t)(ac->env_head_abs_idx % ac->env_capacity);
        ac->env[slot] = env[i];
        ac->env_head_abs_idx++;
    }
    if (ac->env_head_abs_idx >= ac->env_capacity) ac->env_filled = 1;
}

void tg_ac_push_a(tg_ac_t *ac, double t_seconds) {
    ac->a_times[ac->a_head] = t_seconds;
    ac->a_head = (ac->a_head + 1) % TG_AC_EVENT_BUF_N;
    if (ac->a_count < TG_AC_EVENT_BUF_N) ac->a_count++;
}

/* Fetch envelope sample at absolute sample index (reads from ring buffer).
 * Returns 0 if the index is outside the buffer's valid window. */
static float env_at(const tg_ac_t *ac, uint64_t abs_idx) {
    uint64_t oldest = (ac->env_head_abs_idx > ac->env_capacity)
                    ? (ac->env_head_abs_idx - ac->env_capacity) : 0;
    if (abs_idx < oldest || abs_idx >= ac->env_head_abs_idx) return 0.0f;
    return ac->env[abs_idx % ac->env_capacity];
}

/* Parabolic interpolation of peak location given three samples. Returns
 * sub-sample offset in [-0.5, +0.5] relative to the center sample. */
static double parabolic_offset(double y_m1, double y_0, double y_p1) {
    double denom = y_m1 - 2.0 * y_0 + y_p1;
    if (fabs(denom) < 1e-20) return 0.0;
    double off = 0.5 * (y_m1 - y_p1) / denom;
    if (off < -0.5) off = -0.5;
    if (off >  0.5) off =  0.5;
    return off;
}

/* qsort comparator for doubles */
static int dcmp(const void *a, const void *b) {
    double da = *(const double*)a, db = *(const double*)b;
    return (da < db) ? -1 : (da > db) ? 1 : 0;
}

static double median(double *v, int n) {
    if (n <= 0) return 0.0;
    qsort(v, n, sizeof(double), dcmp);
    if (n & 1) return v[n/2];
    return 0.5 * (v[n/2 - 1] + v[n/2]);
}

/* Industry-standard linear amplitude formula (from Witschi / Chinese
 * timegrapher documentation):
 *
 *     amp = (3600 * lift_deg) / (t_AC * pi * BPH)
 *
 * Equivalent to the small-angle approximation
 *     amp ~= lift / (2 * sin(pi * t_AC / T))
 * in the linear regime. Matches what commercial timegraphers display. */
static double amp_from_gap(double t_ac, double period_s, double lift_deg) {
    if (t_ac <= 0 || period_s <= 0) return 0.0;
    /* BPH = 3600 / period_s */
    double bph = 3600.0 / period_s;
    double denom = t_ac * M_PI * bph;
    if (denom < 1e-9) return 0.0;
    return (3600.0 * lift_deg) / denom;
}

int tg_ac_estimate(tg_ac_t *ac,
                   double expected_period_s,
                   double lift_angle_deg,
                   double *out_period_s,
                   double *out_amp_deg,
                   double *out_beat_error_ms,
                   int    *out_beats_used)
{
    if (ac->a_count < 4) return 0;
    if (expected_period_s <= 0) return 0;
    if (!ac->env_filled) return 0;

    /* ----- 1. ACF-based period -----
     *
     * Compute r(k) = sum over window of env[i] * env[i + k] for k in
     * [k_min, k_max] where [k_min, k_max] = ±10% of expected period.
     * Pick lag with maximum r and refine with parabolic interpolation.
     *
     * Window: most-recent 32 beats worth of envelope.               */
    uint64_t fs = (uint64_t)ac->fs;
    uint64_t expected_k = (uint64_t)(expected_period_s * fs);
    /* Narrow search: once we're locked, the beat period is known to
     * within a small fraction of a percent; ±3% is generous. Keeping
     * this narrow is important for runtime (ACF cost is window * range). */
    uint64_t k_min = (uint64_t)(0.97 * expected_k);
    uint64_t k_max = (uint64_t)(1.03 * expected_k);
    if (k_max <= k_min) return 0;

    uint64_t win_samples = 16 * expected_k;  /* 16 beats ≈ 2 s typical */
    /* Cap at buffer size minus the max lag we'll need. */
    uint64_t max_win = ac->env_capacity - k_max - 1;
    if (win_samples > max_win) win_samples = max_win;
    if (win_samples < 4 * expected_k) return 0;  /* need at least 4 beats */

    /* Start the window far enough back that head - win - k_max is valid */
    uint64_t head = ac->env_head_abs_idx;
    uint64_t start = (head > win_samples + k_max)
                   ? (head - win_samples - k_max)
                   : 0;
    uint64_t end   = start + win_samples;
    if (end > head) end = head;
    win_samples = end - start;

    /* V5.4 perf: copy the working window into a flat scratch buffer
     * so the ACF inner loop avoids modulo and per-sample branch in
     * env_at(). Window is start .. end + k_max, total win_samples + k_max.
     *
     * On a 30-second 48 kHz recording with 16-beat window and ±3% lag
     * search, the inner loop runs ~480 lags × 128000 samples = 61M ops
     * per estimate call. Removing modulo and call overhead makes this
     * ~5-10× faster -- tg_dump on the longer recordings goes from
     * timing out to completing in well under a second. */
    size_t   span = (size_t)(win_samples + k_max);
    /* Allocate locally; small enough to put on stack at typical sizes
     * (~140 KB for 30 s of audio at 48 kHz), but we use heap to be
     * safe across embedded targets and high sample rates. */
    float *scratch = (float*)malloc(span * sizeof(float));
    if (!scratch) return 0;
    for (size_t i = 0; i < span; ++i) {
        scratch[i] = env_at(ac, start + (uint64_t)i);
    }

    double best_r = -1.0;
    uint64_t best_k = expected_k;
    double r_m1 = 0.0, r_0 = 0.0, r_p1 = 0.0;

    for (uint64_t k = k_min; k <= k_max; ++k) {
        double r = 0.0;
        const float *a = scratch;
        const float *b = scratch + k;
        for (uint64_t i = 0; i < win_samples; ++i) {
            r += (double)a[i] * (double)b[i];
        }
        if (r > best_r) {
            best_r = r;
            best_k = k;
        }
    }

    /* Refine with parabolic interp if we can fetch neighbors. */
    if (best_k > k_min && best_k < k_max) {
        r_0 = best_r;
        double r_lo = 0.0, r_hi = 0.0;
        const float *a   = scratch;
        const float *blo = scratch + best_k - 1;
        const float *bhi = scratch + best_k + 1;
        for (uint64_t i = 0; i < win_samples; ++i) {
            double av = (double)a[i];
            r_lo += av * (double)blo[i];
            r_hi += av * (double)bhi[i];
        }
        r_m1 = r_lo; r_p1 = r_hi;
    } else {
        r_m1 = r_0 = r_p1 = best_r;
    }
    free(scratch);

    double sub = parabolic_offset(r_m1, r_0, r_p1);
    double period_s = ((double)best_k + sub) / ac->fs;

    /* ----- 2. Median A->C gap per alternating beat parity -----
     *
     * Take the last N A events (up to 32). For each, find the max of
     * the envelope in the window (A_time, A_time + 0.5*period). The
     * gap from A to that max is the A->C interval for that beat.
     * Split into odd-indexed and even-indexed beats; take the median
     * of each; report their average as amplitude and their difference
     * as beat error.
     */
    int max_beats = 32;
    if (ac->a_count < max_beats) max_beats = ac->a_count;
    if (max_beats < 4) return 0;

    /* Per-beat A->C gaps (used for amplitude); collected for all beats
     * regardless of parity. Beat error is computed separately from the
     * A-to-A intervals (the canonical timegrapher convention). */
    double ac_gaps[32];
    int n_gaps = 0;

    /* Collect raw A times in chronological order so we can compute
     * adjacent A-to-A intervals correctly. We walk the ring buffer
     * from the most recent backward, but store into a temp array
     * indexed by chronological order. */
    double a_chrono[32];
    int n_chrono = 0;
    for (int i = max_beats - 1; i >= 0; --i) {
        int idx = (ac->a_head - 1 - i + TG_AC_EVENT_BUF_N) % TG_AC_EVENT_BUF_N;
        a_chrono[n_chrono++] = ac->a_times[idx];
    }

    for (int i = 0; i < n_chrono; ++i) {
        double t_a = a_chrono[i];
        uint64_t a_sample = (uint64_t)(t_a * ac->fs);
        uint64_t search_end = a_sample + (uint64_t)(0.5 * period_s * ac->fs);

        uint64_t oldest = (head > ac->env_capacity) ? (head - ac->env_capacity) : 0;
        if (a_sample < oldest || search_end >= head) continue;

        /* Skip past the A's own impulse cluster and any intermediate
         * sub-impulses to find the actual C peak. Use 3% of the beat
         * period (matches the detector's C-search-skip; see
         * libtimegrapher design.md sec 3.5). 1.5 ms minimum so we
         * always step past A's own onset spike. */
        double skip_s = 0.03 * period_s;
        if (skip_s < 0.0015) skip_s = 0.0015;
        uint64_t skip = (uint64_t)(skip_s * ac->fs);
        if (a_sample + skip >= search_end) continue;
        uint64_t s0 = a_sample + skip;

        double max_v = -1.0;
        uint64_t max_idx = s0;
        for (uint64_t s = s0; s < search_end; ++s) {
            double v = env_at(ac, s);
            if (v > max_v) { max_v = v; max_idx = s; }
        }
        double y_m1 = (max_idx > 0) ? env_at(ac, max_idx - 1) : 0.0;
        double y_0  = max_v;
        double y_p1 = env_at(ac, max_idx + 1);
        double sub_c = parabolic_offset(y_m1, y_0, y_p1);
        double t_c = ((double)max_idx + sub_c) / ac->fs;

        /* V5.4: if onset placement is selected, walk back from the C
         * peak to find the half-height crossing. Same algorithm as
         * the detector (libtimegrapher detector.c find_c_onset).
         * Falls back to peak silently if onset isn't found. */
        if (ac->use_c_onset && max_v > 0.0) {
            double threshold = 0.5 * max_v;
            uint64_t dwell  = (uint64_t)(0.0003 * ac->fs);   /* 0.3 ms */
            if (dwell < 2) dwell = 2;
            uint64_t search_max = (uint64_t)(0.005 * ac->fs); /* 5 ms */

            uint64_t earliest = (max_idx > search_max) ? (max_idx - search_max) : s0;
            if (earliest < s0) earliest = s0;

            uint64_t consecutive_below = 0;
            int      have_above        = 0;
            uint64_t last_above_idx    = 0;
            double   last_above_val    = 0.0;

            for (uint64_t s = max_idx; s > earliest; ) {
                --s;
                double v = env_at(ac, s);
                if (v >= threshold) {
                    have_above        = 1;
                    last_above_idx    = s;
                    last_above_val    = v;
                    consecutive_below = 0;
                } else {
                    consecutive_below++;
                    if (have_above && consecutive_below >= dwell) {
                        /* Linear interp on the threshold-crossing. */
                        double v_prev = (last_above_idx > 0)
                                            ? env_at(ac, last_above_idx - 1)
                                            : 0.0;
                        double frac = 0.0;
                        if (last_above_val > v_prev) {
                            frac = (threshold - v_prev) / (last_above_val - v_prev);
                            if (frac < 0.0) frac = 0.0;
                            if (frac > 1.0) frac = 1.0;
                        }
                        double t_onset =
                            ((double)last_above_idx + (frac - 1.0)) / ac->fs;
                        t_c = t_onset;  /* override: onset replaces peak time */
                        break;
                    }
                }
            }
            /* If we exit the loop without break, t_c stays at peak. */
        }

        double gap = t_c - t_a;
        if (gap <= 0 || gap >= 0.5 * period_s) continue;

        if (n_gaps < 32) ac_gaps[n_gaps++] = gap;
    }

    if (n_gaps < 4) return 0;

    /* Amplitude: median A->C gap (single population, all beats). */
    double med_gap  = median(ac_gaps, n_gaps);
    double amp      = amp_from_gap(med_gap, period_s, lift_angle_deg);

    /* Beat error: median A-to-A interval, split by parity.
     *
     * In a properly-set watch, consecutive A-to-A intervals are equal
     * (= beat_period). When the balance is not centered between the
     * pallet stones at rest ("out of beat"), the unlock fires earlier
     * on one side and later on the other, producing alternating
     * long/short A-to-A intervals.
     *
     * Beat error (timegrapher convention) is the half-difference
     * between the two medians, expressed in milliseconds. */
    double aa_long  [32];
    double aa_short [32];
    int n_long = 0, n_short = 0;
    for (int i = 1; i < n_chrono; ++i) {
        double dt = a_chrono[i] - a_chrono[i-1];
        if (dt <= 0 || dt > 1.5 * period_s) continue;  /* skip outliers */
        /* Parity: i odd -> one population, i even -> other. */
        if (i & 1) { if (n_long  < 32) aa_long [n_long++]  = dt; }
        else       { if (n_short < 32) aa_short[n_short++] = dt; }
    }

    double beat_err_ms = 0.0;
    if (n_long >= 2 && n_short >= 2) {
        double med_long  = median(aa_long,  n_long);
        double med_short = median(aa_short, n_short);
        beat_err_ms = 0.5 * 1000.0 * fabs(med_long - med_short);
    }

    ac->last_period_s      = period_s;
    ac->last_amp_deg       = amp;
    ac->last_beat_error_ms = beat_err_ms;
    ac->last_beats_used    = n_gaps;

    *out_period_s      = period_s;
    *out_amp_deg       = amp;
    *out_beat_error_ms = beat_err_ms;
    *out_beats_used    = n_gaps;
    return 1;
}
