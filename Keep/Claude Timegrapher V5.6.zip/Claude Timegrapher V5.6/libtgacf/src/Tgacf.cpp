/* Tgacf.cpp -- Public tgacf_* API wrapper.
 *
 * Thin wrapper around the V4.5-derived autocorrelation implementation
 * in Autocorr_internal.cpp. The split exists so the public API can
 * evolve (configuration fields, runtime setters, V5.4 placement
 * support) without disturbing the proven inner-loop math, which is
 * kept intact for stability of numerical results across versions.
 *
 * Provides:
 *   - tgacf_config_t with sample_rate, history_seconds, c_placement.
 *   - tgacf_create / tgacf_destroy / tgacf_reset lifecycle.
 *   - tgacf_push_envelope / tgacf_push_a_event streaming inputs.
 *   - tgacf_estimate    -- compute period, amplitude, beat error.
 *   - tgacf_set_c_placement / tgacf_get_c_placement (V5.4 runtime
 *     control).
 *
 * The c_placement setting on this estimator is independent of the
 * detector's setting -- they're separate libraries with separate
 * configurations. To keep amplitude conventions consistent across
 * libraries, set both with the same TG_C_PLACEMENT_* value.
 *
 * V5.5: file renamed from tgacf.c to Tgacf.cpp; compiles under C++17.
 * Public API is C-stable via extern "C" guards in Tgacf.h, so callers
 * from C, C++, Rust, Python (cffi/cython), etc. see the same symbols.
 */
#include "Tgacf.h"
#include "Autocorr_internal.h"

#include <stdlib.h>
#include <string.h>

/* Opaque public type. The internal autocorrelation state lives here.
 * Callers only ever see tgacf_estimator_t* and never reach into the
 * struct -- the struct definition is hidden in this .cpp so the
 * layout can change without breaking ABI. */
struct tgacf_estimator {
    tg_ac_t internal;
};

/* Populate a tgacf_config_t with library defaults. Callers should
 * always start from this and then override fields they care about,
 * so future-added fields get safe defaults rather than uninitialized
 * garbage. */
void tgacf_config_default(tgacf_config_t *cfg) {
    if (!cfg) return;
    cfg->sample_rate     = 48000.0;
    cfg->history_seconds = 3.0;
    /* V5.4 default matches the detector: peak placement, V5.0-V5.3
     * compatible amplitude convention. */
    cfg->c_placement     = TG_C_PLACEMENT_PEAK;
}

/* Construct a new estimator. Returns NULL on bad config (sample_rate
 * non-positive) or out-of-memory. The estimator owns its envelope
 * ring buffer (sized to history_seconds * sample_rate; default 3 s
 * = ~144 KB at 48 kHz). Free with tgacf_destroy. */
tgacf_estimator_t *tgacf_create(const tgacf_config_t *cfg) {
    if (!cfg || cfg->sample_rate <= 0.0) return NULL;
    tgacf_estimator_t *e = (tgacf_estimator_t*)calloc(1, sizeof(*e));
    if (!e) return NULL;
    double hist = (cfg->history_seconds > 0.0) ? cfg->history_seconds : 3.0;
    if (tg_ac_init_ex(&e->internal, cfg->sample_rate, hist) != 0) {
        free(e);
        return NULL;
    }
    /* V5.4: bridge the public enum (TG_C_PLACEMENT_*) to the internal
     * boolean flag. The internal estimator only needs to know "do I
     * find C at peak (false) or at onset (true)?", which collapses
     * the placement enum to a single bit. */
    e->internal.use_c_onset = (cfg->c_placement == TG_C_PLACEMENT_ONSET);
    return e;
}

void tgacf_destroy(tgacf_estimator_t *e) {
    if (!e) return;
    tg_ac_destroy(&e->internal);   /* frees the env ring buffer */
    free(e);
}

/* Drop all accumulated state (envelope buffer contents, A event
 * history, cached results). The estimator remains valid for further
 * use; subsequent push_envelope/push_a_event resumes accumulating. */
void tgacf_reset(tgacf_estimator_t *e) {
    if (!e) return;
    tg_ac_reset(&e->internal);
}

/* Push a block of envelope samples. abs_sample_idx is the absolute
 * index in the caller's stream of env[0]. Used to keep the rolling
 * buffer's coordinate system in sync with the A event timestamps
 * pushed via tgacf_push_a_event (which are seconds, not samples). */
void tgacf_push_envelope(tgacf_estimator_t *e,
                         const float *env, size_t n,
                         uint64_t abs_sample_idx)
{
    if (!e || !env) return;
    /* The internal implementation uses its own internal abs-index
     * counter, advanced by the count of pushed samples. We pass
     * abs_sample_idx through by syncing the internal counter to it
     * before pushing. */
    if (e->internal.env_head_abs_idx != abs_sample_idx) {
        /* Advance or rewind the internal counter to abs_sample_idx.
         * This is safe because the internal buffer is overwritten
         * on every push, and abs_sample_idx defines where the next
         * write goes. */
        e->internal.env_head_abs_idx = abs_sample_idx;
    }
    tg_ac_push_envelope(&e->internal, env, n);
}

/* Record an A event time (seconds, absolute). Stored in a small
 * ring buffer (TGACF_EVENT_BUF_N entries, currently 64) so the
 * estimator always has the most recent A history available for
 * gap calculation. */
void tgacf_push_a_event(tgacf_estimator_t *e, double t_seconds) {
    if (!e) return;
    tg_ac_push_a(&e->internal, t_seconds);
}

/* Compute the current readout. Returns 1 if a result was produced
 * (out fully populated, valid=1), 0 if there isn't enough history
 * yet (the estimator needs at least 4 A events and a fully filled
 * envelope buffer before it produces results).
 *
 * expected_period_s is the nominal beat period (typically from
 * tg_result_t.measured_period_s). The ACF search is narrowed to
 * +-3% around this prior, so a stale or missing prior degrades
 * accuracy. lift_angle_deg is the watch's lift angle, plugged into
 *   amp = (3600 * lift) / (t_AC * pi * BPH). */
int tgacf_estimate(tgacf_estimator_t *e,
                   double expected_period_s,
                   double lift_angle_deg,
                   tgacf_result_t *out)
{
    if (!e || !out) return 0;
    memset(out, 0, sizeof(*out));
    double period_s = 0, amp_deg = 0, beat_err_ms = 0;
    int    beats_used = 0;
    int rc = tg_ac_estimate(&e->internal,
                            expected_period_s, lift_angle_deg,
                            &period_s, &amp_deg, &beat_err_ms, &beats_used);
    if (rc != 1) return 0;
    out->period_s      = period_s;
    out->amplitude_deg = amp_deg;
    out->beat_error_ms = beat_err_ms;
    out->beats_used    = beats_used;
    out->valid         = 1;
    return 1;
}

/* V5.4: runtime placement control.
 *
 * The setter is a one-line update of the internal use_c_onset flag;
 * it takes effect on the next call to tgacf_estimate. There's no
 * need to flush or reset state -- the change only affects how the
 * A->C gap is measured during the estimate, not what's stored in
 * the buffers. */
tg_c_placement_t tgacf_get_c_placement(const tgacf_estimator_t *e) {
    if (!e) return TG_C_PLACEMENT_PEAK;
    return e->internal.use_c_onset ? TG_C_PLACEMENT_ONSET
                                   : TG_C_PLACEMENT_PEAK;
}

void tgacf_set_c_placement(tgacf_estimator_t *e, tg_c_placement_t mode) {
    if (!e) return;
    /* Reject unknown values silently rather than asserting; a future
     * version could add new placement modes and we don't want this
     * to be a hard error if a forward-compatible caller passes one. */
    if (mode != TG_C_PLACEMENT_PEAK && mode != TG_C_PLACEMENT_ONSET) return;
    e->internal.use_c_onset = (mode == TG_C_PLACEMENT_ONSET);
}
