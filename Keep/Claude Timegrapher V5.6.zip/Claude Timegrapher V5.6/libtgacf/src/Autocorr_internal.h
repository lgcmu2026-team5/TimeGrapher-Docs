/* Autocorr_internal.h -- window-averaged period and amplitude estimation.
 *
 * Provides a running estimator that maintains a rolling buffer of
 * envelope samples and recent A event times, and on demand computes:
 *
 *   - ACF-peak period:  lag at which the envelope autocorrelates with
 *                       itself, searched in a narrow range around the
 *                       expected beat period; sub-sample accurate by
 *                       parabolic interpolation at the ACF peak.
 *
 *   - Averaged A->C gap: extract one-beat windows starting at each
 *                        recent A event, take the MEDIAN peak-time of
 *                        those windows. Median is robust to occasional
 *                        missed/extra ticks. Separate medians for
 *                        odd-indexed and even-indexed beats give the
 *                        beat-error between the two pallet stones.
 *
 * Memory: the envelope ring buffer is heap-allocated and sized to hold
 * 3 seconds of audio at the configured sample rate (enough for 16 beats
 * at any supported BPH). At 384 kHz this is ~4.6 MB. For lower sample
 * rates or memory-constrained targets, the user can pass a smaller
 * `env_seconds` into tg_ac_init_ex.
 */
#ifndef TG_AUTOCORR_H
#define TG_AUTOCORR_H

#include <stddef.h>
#include <stdint.h>

#define TG_AC_EVENT_BUF_N   64             /* last 64 A event times     */

typedef struct {
    double   fs;

    /* Heap-allocated rolling envelope ring buffer. Sized at init time
     * to hold env_capacity samples (~3 seconds of audio by default). */
    float   *env;
    size_t   env_capacity;
    uint64_t env_head_abs_idx;   /* abs sample idx of next write slot  */
    int      env_filled;         /* 1 once we've written env_capacity  */

    /* Rolling A event times (absolute, seconds) */
    double   a_times[TG_AC_EVENT_BUF_N];
    int      a_count;
    int      a_head;

    /* Cached outputs (valid only when last computed successfully) */
    double   last_period_s;
    double   last_amp_deg;
    double   last_beat_error_ms;
    int      last_beats_used;

    /* V5.4: when use_c_onset is non-zero, tg_ac_estimate uses the
     * C-cluster onset (backward-walked from the envelope max with
     * half-height threshold) for the A->C gap, instead of the C peak.
     * Mirrors the detector's TG_C_PLACEMENT_ONSET mode. */
    int      use_c_onset;
} tg_ac_t;

/* Initialize with sample rate. Allocates env buffer sized for ~3 seconds
 * (enough for 16 beats at any supported BPH). Returns 0 on success. */
int  tg_ac_init(tg_ac_t *ac, double fs);

/* Variant allowing custom history window. env_seconds must be >= 2. */
int  tg_ac_init_ex(tg_ac_t *ac, double fs, double env_seconds);

void tg_ac_destroy(tg_ac_t *ac);
void tg_ac_reset  (tg_ac_t *ac);

/* Append a block of envelope samples into the rolling buffer. */
void tg_ac_push_envelope(tg_ac_t *ac, const float *env, size_t n);

/* Record an A event time (seconds). */
void tg_ac_push_a(tg_ac_t *ac, double t_seconds);

/* Estimate period, amplitude, and beat error over the last 32 beats.
 *
 * expected_period_s : nominal beat period from BPH (search is narrowed
 *                     to ±3% around this).
 * lift_angle_deg    : watch lift angle, used to convert A->C gap to deg.
 *
 * Returns 1 on success (results written to out_*), 0 if there isn't
 * enough history yet. */
int tg_ac_estimate(tg_ac_t *ac,
                   double expected_period_s,
                   double lift_angle_deg,
                   double *out_period_s,
                   double *out_amp_deg,
                   double *out_beat_error_ms,
                   int    *out_beats_used);

#endif
