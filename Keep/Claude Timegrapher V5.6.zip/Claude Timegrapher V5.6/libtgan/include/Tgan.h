/* Tgan.h - V5.0 timegrapher analytics layer.
 *
 * Consumes tg_event_t timestamps from libtimegrapher and produces:
 *   - per-event amplitude (with physically-derived A->C pairing)
 *   - predicted-time gate validation (in_window flag + signed error)
 *   - tic/toc parity per beat
 *   - phase-tracking PLL across A events
 *
 * Stateful: maintains a phase reference that drifts gently with each
 * in-window event. Reset on sync loss (caller invokes tga_reset).
 *
 * Designed to be called once per tg_process() block. The analyzer
 * remembers the last A across calls to handle pairs that span block
 * boundaries.
 */
#ifndef TGAN_H
#define TGAN_H

#include <stddef.h>
#include <stdint.h>
#include "Timegrapher.h"   /* for tg_event_t and TG_EVENT_* enums */

#ifdef __cplusplus
extern "C" {
#endif

/* ====================== Predicted-time gate ====================== */

typedef enum {
    TGA_GATE_OFF    = 0,   /* no temporal validation                 */
    TGA_GATE_LOOSE  = 1,   /* +/- 25% of beat period                 */
    TGA_GATE_MEDIUM = 2,   /* +/- 15% of beat period                 */
    TGA_GATE_TIGHT  = 3,   /* +/-  7% of beat period                 */
    TGA_GATE_CUSTOM = 4    /* use cfg.custom_window_pct              */
} tga_gate_t;

/* ====================== configuration ============================ */

typedef struct {
    /* Required */
    double  bph;
    double  beat_period_s;       /* = 3600/BPH                       */
    double  lift_angle_deg;      /* watch-specific, e.g. 50 or 52    */

    /* A->C pairing window (physics-derived from amplitude bounds).
     * Both 0 -> defaults: 80 / 400 deg.
     * Window: t_AC in [(3600*lift)/(pair_amp_max*pi*BPH),
     *                  (3600*lift)/(pair_amp_min*pi*BPH)] */
    double  pairing_amp_min;
    double  pairing_amp_max;

    /* Display / diagnostic amplitude range. Both 0 -> defaults: 100 / 400.
     * Computed amplitudes outside this range mark amplitude_valid=0
     * but are still emitted (the value is preserved for diagnostics). */
    double  amplitude_min_deg;
    double  amplitude_max_deg;

    /* Predicted-time gate. */
    tga_gate_t  gate;
    double      custom_window_pct;   /* [0.01, 0.45] when gate=CUSTOM */

    /* If 1, drop out-of-window events from the output. */
    int     suppress_out_of_window_events;
} tga_config_t;

void tga_config_default(tga_config_t *cfg);

/* ===================== per-event analytics ======================= */

typedef struct {
    /* Mirror of tg_event_t fields */
    double           time_seconds;
    uint64_t         sample_index;
    double           sub_sample_offset;
    float            peak_value;
    tg_event_type_t  type;
    int              is_pre_sync;

    /* Per-event amplitude (A->C pair) */
    double           amplitude_deg;     /* 0 if not paired              */
    int              amplitude_valid;   /* 1 if in [amp_min, amp_max]   */

    /* Predicted-time validation */
    int              is_in_window;
    double           predicted_time_seconds;
    double           timing_error_ms;   /* signed (actual - predicted)  */

    /* Tic/toc parity */
    int              parity;            /* 0 = tic, 1 = toc             */
    double           grid_deviation_ms; /* alias of timing_error_ms     */
} tga_event_t;

/* ============================ API ================================ */

typedef struct tga_analyzer tga_analyzer_t;

tga_analyzer_t *tga_create (const tga_config_t *cfg);
void            tga_destroy(tga_analyzer_t *a);
void            tga_reset  (tga_analyzer_t *a);

/* Update beat period if PLL has drifted. Cheap to call every block. */
void tga_update_period(tga_analyzer_t *a, double new_period_s);

/* Notify the analyzer that sync was acquired. The analyzer takes
 * `sync_event_time` as the phase reference. If this isn't called,
 * the analyzer auto-acquires phase from the first A event it sees. */
void tga_notify_sync_acquired(tga_analyzer_t *a, double sync_event_time);

/* Notify the analyzer that sync was lost. Phase reference is cleared. */
void tga_notify_sync_lost(tga_analyzer_t *a);

/* Analyze a batch of events. Returns the number written to `out`.
 * If `out_capacity` is too small, the excess is dropped (partial result).
 * Caller can check rc == n_in for completeness. */
size_t tga_analyze(tga_analyzer_t *a,
                   const tg_event_t *events, size_t n_in,
                   tga_event_t *out, size_t out_capacity);

/* Runtime gate change. */
void        tga_set_gate(tga_analyzer_t *a, tga_gate_t gate, double window_pct);
tga_gate_t  tga_get_gate(const tga_analyzer_t *a);
double      tga_get_window_pct(const tga_analyzer_t *a);

#ifdef __cplusplus
}
#endif

#endif /* TGAN_H */
