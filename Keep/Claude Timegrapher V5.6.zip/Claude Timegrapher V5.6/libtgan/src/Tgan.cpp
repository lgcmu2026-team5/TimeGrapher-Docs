/* Tgan.cpp -- Per-event amplitude analyzer.
 *
 * libtgan is a pure post-processor: it takes the tg_event_t stream
 * produced by libtimegrapher and emits tga_event_t (the same event
 * plus per-pair amplitude). It does no DSP and buffers no audio.
 *
 * State maintained:
 *   - The most recent A event (to pair with the next C across batches).
 *     A and C are emitted in separate calls to tga_analyze whenever
 *     they happen to fall on different sample blocks; the analyzer
 *     bridges that boundary.
 *
 *   - A phase reference and event-index counter, used by the
 *     predicted-time pairing gate (V5.1 addition). The gate predicts
 *     when the next A and C *should* arrive based on the locked beat
 *     period and rejects pairings that fall too far outside that
 *     window. This filters out spurious C-without-A or
 *     A-without-matching-C glitches in noisy recordings.
 *
 *   - The current beat period and BPH (for the pairing window math).
 *
 * V5.4 placement compatibility:
 *   This file is unchanged for V5.4 -- it always reads time_seconds
 *   off the incoming tg_event_t and pairs against that. Whichever
 *   timing the detector chose to emit there (peak in PEAK mode, onset
 *   in ONSET mode) is what gets used in the A->C gap and amplitude
 *   formula. There is no per-library placement setting on libtgan.
 *
 * V5.5: file renamed from tgan.c to Tgan.cpp; compiles under C++17.
 * No algorithmic change.
 */
#include "Tgan.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct tga_analyzer {
    tga_config_t cfg;

    /* Pending A across block boundaries (so a C in the next block can
     * still find its partner A). */
    int    have_pending_a;
    double pending_a_time;

    /* Phase reference for the predicted-time gate. */
    int    gate_active;
    double phase_ref_time;
    int    phase_event_count;   /* count of A events since phase_ref */
};

/* ---------- helpers ---------- */

static double compute_amplitude_deg(double t_ac, double bph, double lift_deg) {
    if (t_ac <= 0.0 || bph <= 0.0 || lift_deg <= 0.0) return 0.0;
    double s = sin(M_PI * t_ac * bph / 7200.0);
    if (s <= 1e-9) return 0.0;
    return (lift_deg * 0.5) / s;
}

static double gate_fraction(const tga_config_t *cfg) {
    switch (cfg->gate) {
    case TGA_GATE_OFF:    return 0.0;
    case TGA_GATE_LOOSE:  return 0.25;
    case TGA_GATE_MEDIUM: return 0.15;
    case TGA_GATE_TIGHT:  return 0.07;
    case TGA_GATE_CUSTOM: {
        double w = cfg->custom_window_pct;
        if (w < 0.01) w = 0.01;
        if (w > 0.45) w = 0.45;
        return w;
    }
    }
    return 0.0;
}

/* ---------- public API ---------- */

void tga_config_default(tga_config_t *cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    cfg->bph                            = 0.0;
    cfg->beat_period_s                  = 0.0;
    cfg->lift_angle_deg                 = 52.0;  /* common modern */
    cfg->pairing_amp_min                = 0.0;   /* default 80    */
    cfg->pairing_amp_max                = 0.0;   /* default 400   */
    cfg->amplitude_min_deg              = 0.0;   /* default 100   */
    cfg->amplitude_max_deg              = 0.0;   /* default 400   */
    cfg->gate                           = TGA_GATE_OFF;
    cfg->custom_window_pct              = 0.0;
    cfg->suppress_out_of_window_events  = 0;
}

tga_analyzer_t *tga_create(const tga_config_t *cfg) {
    if (!cfg) return NULL;
    tga_analyzer_t *a = (tga_analyzer_t*)calloc(1, sizeof(*a));
    if (!a) return NULL;
    a->cfg = *cfg;
    return a;
}

void tga_destroy(tga_analyzer_t *a) { free(a); }

void tga_reset(tga_analyzer_t *a) {
    if (!a) return;
    a->have_pending_a    = 0;
    a->pending_a_time    = 0.0;
    a->gate_active       = 0;
    a->phase_ref_time    = 0.0;
    a->phase_event_count = 0;
}

void tga_update_period(tga_analyzer_t *a, double new_period_s) {
    if (!a || new_period_s <= 0.0) return;
    a->cfg.beat_period_s = new_period_s;
    a->cfg.bph           = 3600.0 / new_period_s;
}

void tga_notify_sync_acquired(tga_analyzer_t *a, double sync_event_time) {
    if (!a) return;
    a->phase_ref_time    = sync_event_time;
    a->phase_event_count = 0;
    a->gate_active       = 1;
}

void tga_notify_sync_lost(tga_analyzer_t *a) {
    if (!a) return;
    a->gate_active       = 0;
    a->phase_event_count = 0;
}

void tga_set_gate(tga_analyzer_t *a, tga_gate_t gate, double window_pct) {
    if (!a) return;
    switch (gate) {
    case TGA_GATE_OFF: case TGA_GATE_LOOSE: case TGA_GATE_MEDIUM:
    case TGA_GATE_TIGHT: case TGA_GATE_CUSTOM:
        a->cfg.gate = gate; break;
    default:
        a->cfg.gate = TGA_GATE_OFF; break;
    }
    if (gate == TGA_GATE_CUSTOM) {
        if (window_pct < 0.01) window_pct = 0.01;
        if (window_pct > 0.45) window_pct = 0.45;
        a->cfg.custom_window_pct = window_pct;
    }
}

tga_gate_t tga_get_gate(const tga_analyzer_t *a) {
    return a ? a->cfg.gate : TGA_GATE_OFF;
}

double tga_get_window_pct(const tga_analyzer_t *a) {
    return a ? gate_fraction(&a->cfg) : 0.0;
}

size_t tga_analyze(tga_analyzer_t *a,
                   const tg_event_t *events, size_t n_in,
                   tga_event_t *out, size_t out_capacity)
{
    if (!a || !events || !out) return 0;

    double bph     = a->cfg.bph;
    double period  = a->cfg.beat_period_s;
    double lift    = a->cfg.lift_angle_deg;

    /* A-to-A spacing IS one beat period (one A per beat). */
    double a_to_a  = period;

    double gate_frac = gate_fraction(&a->cfg);
    double amp_min   = (a->cfg.amplitude_min_deg > 0.0)
                     ? a->cfg.amplitude_min_deg : 100.0;
    double amp_max   = (a->cfg.amplitude_max_deg > 0.0)
                     ? a->cfg.amplitude_max_deg : 400.0;
    double pair_amp_min = (a->cfg.pairing_amp_min > 0.0)
                        ? a->cfg.pairing_amp_min : 80.0;
    double pair_amp_max = (a->cfg.pairing_amp_max > 0.0)
                        ? a->cfg.pairing_amp_max : 400.0;

    /* Physics-derived A->C pairing window.
     *
     * The amplitude formula is:
     *
     *     amplitude_deg = (3600 * lift) / (t_AC * pi * BPH)
     *
     * which implies that for a given target amplitude range
     * [pair_amp_min, pair_amp_max], the corresponding A->C gap
     * range is:
     *
     *     t_AC_min = k / pair_amp_max     (highest amp -> shortest gap)
     *     t_AC_max = k / pair_amp_min     (lowest  amp -> longest  gap)
     *
     * with k = (3600 * lift) / (pi * BPH).
     *
     * The pairing logic uses this window to decide whether a given
     * (A, C) candidate pair is physically plausible: if the C arrives
     * sooner than t_AC_min or later than t_AC_max relative to its A,
     * we don't pair them (the C must be a spurious event, or the A
     * we're pairing with is the wrong A).
     *
     * We additionally cap t_AC_max at half the beat period to prevent
     * the C from being matched to the *previous* beat's A (the next
     * A is always at most one period later than its A). */
    double t_ac_min = 0.001, t_ac_max = 0.05;
    if (bph > 0.0 && lift > 0.0) {
        double k = (3600.0 * lift) / (M_PI * bph);
        t_ac_min = k / pair_amp_max;
        t_ac_max = k / pair_amp_min;
        if (a_to_a > 0.0 && t_ac_max > 0.5 * a_to_a) t_ac_max = 0.5 * a_to_a;
        if (t_ac_min < 0.001) t_ac_min = 0.001;
    }

    size_t out_count = 0;

    for (size_t i = 0; i < n_in; ++i) {
        if (out_count >= out_capacity) break;
        const tg_event_t *src = &events[i];
        tga_event_t       ev;
        memset(&ev, 0, sizeof(ev));
        ev.time_seconds      = src->time_seconds;
        ev.sample_index      = src->sample_index;
        ev.sub_sample_offset = src->sub_sample_offset;
        ev.peak_value        = src->peak_value;
        ev.type              = src->type;
        ev.is_pre_sync       = src->is_pre_sync;

        int pre_sync = src->is_pre_sync || (bph <= 0.0);

        /* ---- A->C pairing & amplitude ------------------------------*/
        if (ev.type == TG_EVENT_C && bph > 0.0) {
            /* Try in-batch pair first (previous emitted event was A). */
            if (out_count > 0
                && out[out_count - 1].type == TG_EVENT_A
                && !out[out_count - 1].is_pre_sync)
            {
                double dt = ev.time_seconds - out[out_count - 1].time_seconds;
                if (dt >= t_ac_min && dt <= t_ac_max) {
                    ev.amplitude_deg = compute_amplitude_deg(dt, bph, lift);
                    ev.amplitude_valid = 1;
                }
            } else if (a->have_pending_a) {
                double dt = ev.time_seconds - a->pending_a_time;
                if (dt >= t_ac_min && dt <= t_ac_max) {
                    ev.amplitude_deg = compute_amplitude_deg(dt, bph, lift);
                    ev.amplitude_valid = 1;
                }
            }
            a->have_pending_a = 0;
        } else if (ev.type == TG_EVENT_A) {
            a->pending_a_time = ev.time_seconds;
            a->have_pending_a = 1;
        }

        /* Display range gate */
        if (ev.amplitude_valid &&
            (ev.amplitude_deg < amp_min || ev.amplitude_deg > amp_max))
        {
            ev.amplitude_valid = 0;
        }

        /* ---- predicted-time gate -----------------------------------*/
        if (!pre_sync && a->gate_active && a_to_a > 0.0
            && ev.type == TG_EVENT_A)
        {
            int    k         = a->phase_event_count;
            double predicted = a->phase_ref_time + (double)k * a_to_a;
            double err_s     = ev.time_seconds - predicted;
            ev.predicted_time_seconds = predicted;
            ev.timing_error_ms        = 1000.0 * err_s;
            ev.parity                 = k & 1;
            ev.grid_deviation_ms      = 1000.0 * err_s;
            if (gate_frac <= 0.0) {
                ev.is_in_window = 1;
            } else {
                double half_window = gate_frac * a_to_a;
                ev.is_in_window = (fabs(err_s) <= half_window) ? 1 : 0;
            }
            /* Phase reference drifts only on in-window events. */
            if (ev.is_in_window) {
                double observed_phase = ev.time_seconds - (double)k * a_to_a;
                a->phase_ref_time += 0.05 * (observed_phase - a->phase_ref_time);
            }
            a->phase_event_count++;
        } else if (!pre_sync && a->gate_active && ev.type == TG_EVENT_C) {
            /* C inherits its A's gate decision. */
            if (out_count > 0 && out[out_count - 1].type == TG_EVENT_A) {
                tga_event_t *prev_a = &out[out_count - 1];
                double dt_obs = ev.time_seconds - prev_a->time_seconds;
                ev.predicted_time_seconds = prev_a->predicted_time_seconds + dt_obs;
                ev.timing_error_ms        = 0.0;
                ev.parity                 = prev_a->parity;
                ev.grid_deviation_ms      = 0.0;
                ev.is_in_window           = prev_a->is_in_window;
            } else {
                ev.is_in_window = 1;  /* orphan C: pass through */
            }
        } else {
            ev.is_in_window = pre_sync ? 0 : 1;
        }

        /* ---- emit ----------------------------------------------------*/
        if (!pre_sync && !ev.is_in_window
            && a->cfg.suppress_out_of_window_events) continue;

        out[out_count++] = ev;
    }

    return out_count;
}
