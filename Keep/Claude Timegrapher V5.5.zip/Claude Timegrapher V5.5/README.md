# Claude Timegrapher V5.5

A streaming C++ library for mechanical-watch audio analysis.  Detects
A (escape unlock) and C (drop / lock) events with sub-sample timing,
identifies BPH from a list of common rates, tracks beat period via a
PLL, and computes per-event amplitude plus window-averaged readouts
via autocorrelation.

The library is implemented in C++17 internally (V5.5) but exposes a
C-stable ABI: every public header wraps its declarations in
`extern "C"`.  Callers in C, C++, Rust, Python (via cffi/cython) etc.
all see the same symbol names.

V5.0 splits the monolithic V4.x library into three independent
libraries that can be used together or individually:

| Library         | Purpose                                          |
|-----------------|--------------------------------------------------|
| libtimegrapher  | Detection: PCM -> A/C event timestamps           |
| libtgan         | Analytics: events -> amplitude, predicted-time   |
| libtgacf        | Analytics: rolling autocorrelation period/amp/BE |

Detection is irreversible (audio -> events).  Analytics are pure
post-processors over events (and optionally envelope), so they can
be re-run with different parameters or replaced with custom logic
without touching the detection pipeline.

## Building

Requires a C++17 compiler (`c++` / `g++` / `clang++`) and POSIX
`make`.  No external dependencies.

```sh
make all       # build all three libs, Tg_dump, integration test
make check     # run the integration test
make clean
```

Each library can also be built standalone:

```sh
cd libtimegrapher && make
cd libtgan        && make
cd libtgacf       && make
```

## Quick example

```c
#include "timegrapher.h"
#include "tgan.h"
#include "tgacf.h"

tg_config_t  tg_cfg;  tg_config_default(&tg_cfg);
tga_config_t an_cfg;  tga_config_default(&an_cfg);
tgacf_config_t acf_cfg; tgacf_config_default(&acf_cfg);

tg_cfg.sample_rate    = 48000.0;
an_cfg.lift_angle_deg = 52.0;
acf_cfg.sample_rate   = 48000.0;

tg_context_t      *tg  = tg_init(&tg_cfg);
tga_analyzer_t    *an  = tga_create(&an_cfg);
tgacf_estimator_t *acf = tgacf_create(&acf_cfg);

while (have_audio) {
    tg_result_t r;
    tg_process(tg, pcm, num_samples, &r);

    if (r.processed_pcm_len > 0)
        tgacf_push_envelope(acf, r.processed_pcm,
                            r.processed_pcm_len,
                            r.processed_pcm_start_sample);

    if (r.sync_status == TG_SYNC_SYNCED)
        tga_update_period(an, r.measured_period_s);

    tga_event_t analyzed[256];
    size_t n = tga_analyze(an, r.events, r.num_events,
                           analyzed, 256);
    for (size_t i = 0; i < n; i++) {
        if (analyzed[i].type == TG_EVENT_A)
            tgacf_push_a_event(acf, analyzed[i].time_seconds);
        /* use analyzed[i].amplitude_deg, .timing_error_ms, etc. */
    }
}
```

For a complete worked example see `tools/Tg_dump.cpp`.  For the full
API reference and parameter descriptions see `docs/api.md`.

## Documentation

- **`docs/design.md`**: algorithms and theory (signal chain, threshold
  tracking, sub-sample timing, Rayleigh phase-score BPH detection,
  PLL sync, amplitude formula, predicted-time gate, A->C pairing
  bounds, A-to-A interval gate, autocorrelation).
- **`docs/api.md`**: API reference with per-parameter descriptions
  and example code for each library.

## Verification

V5.0 produces results functionally equivalent to V4.5 on five
reference recordings (4 modern automatic movements at 21600/28800 BPH
and one Russian quartz):

| watch                  | V4.5                            | V5.0                            |
|------------------------|---------------------------------|---------------------------------|
| ST3600 (21600)         | 181/181 309.7 deg, 172 pairs    | 181/181 309.8 deg, 171 pairs    |
| NH35   (21600)         | 182/182 266.8 deg, 172 pairs    | 182/182 266.8 deg, 171 pairs    |
| 8215   (21600)         | 182/182 274.4 deg, 173 pairs    | 182/182 274.4 deg, 172 pairs    |
| Hulk   (28800)         | 242/242 277.4 deg, 226 pairs    | 242/242 277.4 deg, 225 pairs    |
| Starbucks (28800)      | 243/243 210.2 deg, 231 pairs    | 243/243 210.2 deg, 230 pairs    |

Counts identical, amplitudes within 0.1 deg, ACF readouts within
0.5 ms period and 0.5 deg amplitude.  Pair-count differences of +-1
are float-precision artifacts at the t_AC bounds.

## Versioning

V5.0 is a major version: APIs differ from V4.x.  Migration notes:

- `tg_event_t` no longer carries `amplitude_deg`, `is_in_window`,
  `predicted_time_seconds`, `timing_error_ms`, `parity`, etc.  Use
  `tga_event_t` from libtgan.
- `tg_result_t` no longer carries ACF fields.  Use `tgacf_result_t`
  from libtgacf.
- Config knobs that controlled analytics moved from `tg_config_t`
  to `tga_config_t` / `tgacf_config_t`.

## File layout

```
.
|-- Makefile                  Top-level build
|-- README.md                 This file
|-- CHANGELOG.md              Version history
|-- VERSION                   Version stamp
|-- docs/
|   |-- design.md             Algorithms and theory
|   `-- api.md                API reference
|-- libtimegrapher/           Detection library
|   |-- include/              Public headers (Bph.h, Detector.h,
|   |                           Dsp.h, Timegrapher.h)
|   |-- src/                  Implementation (Bph.cpp, Detector.cpp,
|   |                           Dsp.cpp, Timegrapher.cpp)
|   `-- test/                 Standalone smoke test (Test_basic.cpp)
|-- libtgan/                  Amplitude + gate analytics
|   |-- include/              Tgan.h
|   `-- src/                  Tgan.cpp
|-- libtgacf/                 Autocorrelation analytics
|   |-- include/              Tgacf.h
|   `-- src/                  Autocorr_internal.{h,cpp}, Tgacf.cpp
|-- tools/
|   `-- Tg_dump.cpp           Reference integration tool
`-- tests/
    `-- Integration_test.cpp  Cross-library smoke test
```

V5.5 renamed all sources from `.c` to `.cpp` and capitalized each
filename's first letter.  The library is built as C++17 internally
but exposes a C-stable ABI (every public header wraps its
declarations in `extern "C"`), so existing C call sites need only
relink against the C++-built archives.
