# Changelog

## V5.5

C++ port. Internal change only — no API or behavior changes.

- **Source files renamed from `.c` to `.cpp`**, with each filename's
  first letter capitalized (e.g. `bph.c` -> `Bph.cpp`,
  `tgacf.c` -> `Tgacf.cpp`, `integration_test.c` ->
  `Integration_test.cpp`). All `#include` directives updated to
  match.

- **Build system** moved from `cc` / `-std=c99` to `c++` /
  `-std=c++17` across all four Makefiles. Each Makefile gained a
  documentation header describing what it builds and why.

- **Public API unchanged.** All headers continue to wrap their
  declarations in `extern "C"` so the library exposes a C-stable
  ABI; callers in C, C++, Rust, Python (via cffi/cython), etc. all
  see the same symbol names. Existing C call sites need only update
  their build to link against the C++-built archives (e.g.
  `g++ ... libtimegrapher.a -lm`) -- no source changes.

- **Documentation pass.** File-level header comments in every .cpp
  expanded to describe the file's role, the algorithms it implements,
  and the V5.x history of changes within it (V5.2 C-search-skip,
  V5.3 BPH guard, V5.4 onset placement, V5.4 ACF perf fix).

- **Verified:** all 11 reference recordings detect identically to
  V5.4 (same BPH, same pair count, same per-event amplitude, same
  ACF amplitude). Integration test (7 cases) passes. Builds clean
  under `c++ -std=c++17` with `-Wall -Wextra -Wno-unused-parameter`,
  zero warnings.

## V5.4

C-event onset detection and placement modes; ACF performance fix.

- **New feature: C-onset detection.** The detector now finds the C
  cluster's rising-edge half-height crossing in addition to its peak.
  Algorithm: walk backward from the C peak in a small envelope ring
  buffer, find the threshold crossing at 0.5 × peak with safeguards
  against in-cluster ringing notches (0.3 ms below-threshold dwell
  required) and against walking past the C cluster into A territory
  (5 ms search bound).

- **New API: placement modes.** `tg_c_placement_t` enum with
  `TG_C_PLACEMENT_PEAK` (default, V5.0-V5.3 behavior) and
  `TG_C_PLACEMENT_ONSET`. Set via `tg_config_t.c_placement` at init
  or `tg_set_c_placement(ctx, mode)` at runtime. The mode controls
  which timing populates the primary fields of `tg_event_t`. Onset
  metadata (`onset_sample_index`, `onset_sub_sample_offset`,
  `onset_time_seconds`, `onset_valid`) is populated regardless of
  mode for downstream code that wants both timings.

- **libtgan**: no API change. Reads `time_seconds` from the events
  and pairs against it. Automatically follows whichever timing the
  detector emitted.

- **libtgacf**: new field `tgacf_config_t.c_placement` (default
  `PEAK`) and runtime setter `tgacf_set_c_placement(acf, mode)`. In
  `ONSET` mode the ACF runs the same backward-walk against its own
  envelope ring buffer to find onset for the amplitude calculation.

- **Performance fix in libtgacf.** The autocorrelation inner loop
  was calling a wrapper function with modulo arithmetic 60M+ times
  per `tgacf_estimate` call, making `tg_dump` hang on recordings
  longer than ~15 seconds. Pre-existing in V5.0-V5.3, exposed when
  testing on 30-second recordings. Fixed by copying the working
  window into a flat scratch buffer once per estimate; inner loop
  is now plain pointer arithmetic. ~10× speedup; 30 s recordings
  complete in well under a second.

- **Verified:** all 11 reference recordings detect the same BPH
  with the same pair count and amplitude in default `PEAK` mode as
  V5.3. `ONSET` mode produces consistent shifts (libtgan and
  libtgacf agree on the magnitude of the change), with shifts
  ranging from +1.6° on synthetic data (where onset and peak
  coincide) to +43° on multi-impulse recordings with long C-cluster
  rise times.

- **Integration test extended** with two `ONSET` mode cases
  (clean synthetic + multi-impulse mid-burst hump) in addition to
  the five `PEAK` mode cases from V5.3.

## V5.3

Bug fix for half-period BPH mis-detection on multi-impulse watches.

- **BPH detection**: `tg_phase_score` was returning the sum of the
  first- and second-harmonic Rayleigh statistics (R1 + R2). The R2
  term was a hold-over from earlier versions when the BPH path saw
  both A and C events (two peaks per period maximize R2). Once the
  BPH path was changed to A-only events, R2 became actively harmful:
  for periodic A-only events, R2 doubles the score for half-period
  candidates because all events project to phase 0 in the doubled-
  frequency space.

  The result: 18000 BPH watches with intermittent secondary echoes
  (small aftershock impulses ~50 ms after each main beat, common on
  vintage / multi-impulse movements like the Waltham V2 recordings)
  could be mis-detected as 36000 BPH. Half-period scoring was
  often higher than true-period scoring on those signals.

- **Fix 1**: `tg_phase_score` now returns R1 only (the standard
  Rayleigh statistic, magnitude of the circular mean of phases).

- **Fix 2**: `tg_bph_pick_by_phase` now computes the median A-to-A
  interval and rejects any candidate period less than 0.7 * median
  as physically implausible. This breaks the period/half-period
  aliasing that R1 alone can't distinguish for perfectly periodic
  events. The median is a robust lower bound: spurious extra events
  can only make it smaller, never larger than the true beat period.

- **Verified results**:

  | Recording        | V5.2     | V5.3     |
  |------------------|----------|----------|
  | Out1.wav (18000) | **36000** -> wrong | 18000 -> correct |
  | Out2.wav (18000) | **36000** -> wrong | 18000 -> correct |
  | Watham V2 (18000)| **36000** -> wrong | 18000 -> correct |
  | ST3600 (21600)   | 21600 ok | 21600 ok |
  | NH35 (21600)     | 21600 ok | 21600 ok |
  | 8215 (21600)     | 21600 ok | 21600 ok |
  | Hulk (28800)     | 28800 ok | 28800 ok |
  | Starbucks (28800)| 28800 ok | 28800 ok |
  | Be6_0 (28800)    | 28800 ok | 28800 ok |
  | Be9_9 (28800)    | 28800 ok | 28800 ok |
  | Wrong_C (21600)  | 21600 ok | 21600 ok |

  All 11 reference recordings now correctly identified. Three
  previously-broken recordings now correct. No regressions on any
  recording previously correct.

## V5.2

Bug fix for "wrong-C" placement on multi-impulse watches.

- **Detector**: when a burst contained multiple sub-impulses, the C
  event could be mis-placed on an early sub-impulse (the A's own
  impulse spike, or an intermediate hump) instead of the actual C
  cluster. This happened because `burst_max` tracked the absolute
  envelope max within the burst, and an early sub-impulse could
  occasionally exceed the height of the real C cluster.

  Observed on a 21600 BPH multi-impulse recording with two distinct
  failure modes:
  - 2 cases at A->C gap of 1.1-1.2 ms (C latched on the first
    sub-impulse spike at burst start)
  - 6 cases at A->C gap of 3.6-4.1 ms (C latched on an intermediate
    hump between A and the real C cluster)

  The actual C cluster in all 8 cases was at 8-12 ms from A.

- **Fix**: track the C-peak separately from `burst_max`, only
  considering envelope samples past a configurable skip window
  (counted from burst start). `burst_max` is unchanged and still
  used for the min-peak height check. If no peak is found past the
  skip window (very short bursts), C falls back to `burst_max_idx`
  for backward compatibility.

- **New API**: `tg_detector_set_c_search_skip(d, skip_s)` for the
  detector. The library calls this at sync acquisition with 3% of
  the beat period (5.0 ms at 21600 BPH, 3.75 ms at 28800 BPH,
  6.0 ms at 18000 BPH). Pre-sync default is 3 ms.

- **Verified results**:

  | Watch         | V5.1                     | V5.2                     |
  |---------------|--------------------------|--------------------------|
  | ST3600        | 171 pairs, 309.8 deg     | identical                |
  | NH35          | 168 pairs, 260.7 deg     | identical                |
  | 8215          | 172 pairs, 274.4 deg     | identical                |
  | Hulk          | 225 pairs, 277.4 deg     | 228 pairs, 277.4 deg     |
  | Starbucks     | 226 pairs, 209.8 deg     | identical                |
  | Be6_0         | 89 pairs, 6.00 ms BE     | identical                |
  | Be9_9         | 117 pairs, 9.90 ms BE    | identical                |
  | Wrong_C       | 163 pairs, 8 wrong-Cs    | 171 pairs, 0 wrong-Cs    |

  Hulk gained 3 pairs (a few previously-mispaired beats now correctly
  placed). Wrong_C gained 8 pairs (the 8 wrong-C cases all fixed).
  No regressions on any other recording.

- New integration test case: synthetic 21600 BPH stream with a
  spurious mid-beat sub-impulse to verify the C-search-skip
  mechanism rejects it.

## V5.1

Bug fixes for high-beat-error watches.

- **Detector**: `samples_since_last_a` (V4.5 A-to-A interval gate) was
  resetting at A-emission time (= burst-end, ~25 ms after C peak),
  not at A-onset time. The gate effectively required
  `(0.7 * period + burst_duration)` between consecutive A onsets.
  For watches with high beat error producing alternating long/short
  A-to-A intervals, the short ones could fall just below the gate.
  The detector then missed the true A onset on every other beat,
  placing A on a later threshold-crossing in the C ramp-up instead
  (giving an A->C gap of ~3.5 ms instead of the real ~7 ms).
  Fix: reset `samples_since_last_a = current - burst_start_idx` so
  it measures true A-to-A.

- **libtgacf**: beat error was computed from the difference between
  odd-beat and even-beat A->C gap medians. That measures impulse-
  duration asymmetry, not the canonical timegrapher beat error
  (which is A-to-A interval asymmetry, i.e. the balance is off-
  center between the pallet stones).
  Fix: compute beat error as `0.5 * |median(long_AA) - median(short_AA)|`
  in milliseconds.

- New integration tests for synthetic streams with 0, 6, and 9.9 ms
  beat error verify both fixes.

### Verified results

Synthetic 21600 BPH streams:
- 0.0 ms beat error -> ACF reads 0.00 ms
- 6.0 ms beat error -> ACF reads 6.00 ms
- 9.9 ms beat error -> ACF reads 9.90 ms

Real recordings (no behavior change):
- ST3600, 8215, Hulk: identical to V5.0
- NH35: 168 pairs (was 171); mean amp 260.7 deg (was 266.8)
- Starbucks: 226 pairs (was 230); mean amp 209.8 deg (was 210.2)

The small shifts on NH35 / Starbucks reflect the corrected detector
behavior: a few previously-mispaired beats are now either correctly
paired (with slightly different A timing) or correctly rejected.

## V5.0

Major restructuring: the V4.x monolithic `libtimegrapher` is split
into three independent libraries.

### Architecture

- **libtimegrapher**: detection only (PCM -> A/C event timestamps).
- **libtgan**: amplitude pairing + predicted-time gate, consuming
  `tg_event_t` from libtimegrapher.
- **libtgacf**: rolling autocorrelation, consuming envelope and A
  event times from libtimegrapher.

### Breaking changes from V4.x

- `tg_event_t` no longer has `amplitude_deg`, `amplitude_valid`,
  `is_in_window`, `predicted_time_seconds`, `timing_error_ms`,
  `parity`, `grid_deviation_ms`. Those moved to `tga_event_t`.
- `tg_result_t` no longer has `acf_period_s`, `acf_amplitude_deg`,
  `acf_beat_error_ms`, `acf_beats_used`, `acf_valid`. Those moved
  to `tgacf_result_t` from `tgacf_estimate()`.
- `tg_config_t` no longer has `event_gate`, `event_window_pct`,
  `suppress_out_of_window_events`, `amplitude_min_deg`,
  `amplitude_max_deg`, `pairing_amp_min`, `pairing_amp_max`,
  `autocorr_enabled`, `autocorr_history_s`. Those moved to
  `tga_config_t` and `tgacf_config_t`.
- Removed: `tg_set_event_gate`, `tg_get_event_gate`,
  `tg_get_event_window_pct`. Replaced by `tga_set_gate` /
  `tga_get_gate` / `tga_get_window_pct`.

### Functional equivalence

V5.0 produces functionally equivalent results to V4.5 on the five
reference recordings (event counts identical, amplitudes within
0.1 deg, ACF readouts within 0.5 ms / 0.5 deg).  Per-event pair
counts may differ by +-1 due to float-precision noise at the t_AC
bound limits.

### Documentation

- New `docs/design.md`: algorithms and theory.
- New `docs/api.md`: API reference with per-parameter descriptions.
- New `tests/integration_test.c`: cross-library smoke test on a
  synthetic 21600 BPH tick stream.


## V4.5

A-to-A minimum interval gate, plus phase-reference seeding fix.

- New `min_a_interval_samples` gate at detector level: a third
  condition (alongside threshold crossing and silence-gate) that
  blocks new A onsets within 0.7 * beat_period of the previous A.
- The counter `samples_since_last_a` resets only when an A is
  successfully emitted.
- Phase reference seeded from the sync-acquisition event instead of
  "the first event after sync acquired".

## V4.4

Physics-derived A->C pairing window.

- New config `pairing_amp_min` (default 80), `pairing_amp_max`
  (default 400).  Pairing window derived from amplitude formula:
    t_AC_min = (3600 * lift) / (pair_amp_max * pi * BPH)
    t_AC_max = (3600 * lift) / (pair_amp_min * pi * BPH)
- Replaces previous `dt < 0.5 * beat_period` rule which allowed
  catastrophically mispaired events to produce 700-5700 deg
  "amplitudes".

## V4.3

Predicted-time validation gate (inspired by Pascal Chour PC-RM3/4).

- New `tg_event_gate_t` enum: OFF/LOOSE/MEDIUM/TIGHT/CUSTOM.
- New event fields: `is_in_window`, `predicted_time_seconds`,
  `timing_error_ms`, `parity` (0=tic, 1=toc), `grid_deviation_ms`.
- Phase reference acquired from sync event; tracked via single-pole
  filter (gain 0.05) on in-window events.
- Amplitude range gate: invalidates events with amplitude outside
  100-400 deg (configurable).

## V4.2

Runtime tunable thresholds.

- `tg_set_onset_fraction`, `tg_set_min_peak_fraction` runtime API.
- `tg_reset()` preserves config including tunable fractions.

## V4.1

Init-time thresholds.

- `cfg.onset_fraction_init`, `cfg.min_peak_fraction_init`.

## V4.0

Practical integration fixes.

- 50 ms envelope delay line for event/PCM alignment.
- `tg_flush()` to drain delay line at end-of-stream.
- Detector state visible in result (onset_threshold,
  min_peak_threshold, noise_floor, reference_peak).
- Sample-rate independence (heap-allocated AC buffer).
